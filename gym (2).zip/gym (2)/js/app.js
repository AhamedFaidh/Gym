/**
 * Main Application Controller for Gym Management System Admin Dashboard
 * Handles full UI interactivity, module routing, modal forms, searches, filters,
 * pagination, check-in simulation, invoicing, trainer list view & plan price editing in Rupees (₹).
 */
document.addEventListener('DOMContentLoaded', () => {
  const THEME_KEY = 'apex_gym_theme';

  // 1. BOOT THEME & CHROME
  const isDark = localStorage.getItem(THEME_KEY) === 'dark';
  document.documentElement.classList.toggle('dark', isDark);
  document.body.classList.toggle('dark', isDark);
  document.documentElement.classList.remove('boot-pending');
  document.documentElement.classList.add('boot-ready');

  // Update theme toggle icon
  const themeToggle = document.getElementById('themeToggle');
  if (themeToggle) {
    const icon = themeToggle.querySelector('[data-icon]');
    if (icon) icon.setAttribute('data-icon', isDark ? 'sun' : 'moon');
  }

  themeToggle?.addEventListener('click', () => {
    const nextDark = !document.documentElement.classList.contains('dark');
    document.documentElement.classList.toggle('dark', nextDark);
    document.body.classList.toggle('dark', nextDark);
    localStorage.setItem(THEME_KEY, nextDark ? 'dark' : 'light');

    const icon = themeToggle.querySelector('[data-icon]');
    if (icon) icon.setAttribute('data-icon', nextDark ? 'sun' : 'moon');
    Icons.mount(themeToggle);

    // Refresh charts with updated contrast
    if (window.GymCharts) {
      window.GymCharts.refreshAll();
    }
  });

  // Sidebar State Persistence & Toggles
  const sidebarRight = document.getElementById('sidebarRight');
  const sidebarLeft = document.getElementById('sidebarLeft');
  const savedRightSidebar = localStorage.getItem('apex_gym_right_sidebar');
  const savedLeftSidebar = localStorage.getItem('apex_gym_left_sidebar');

  if (savedRightSidebar === 'collapsed') {
    sidebarRight?.classList.add('collapsed');
    document.documentElement.classList.add('right-sidebar-collapsed');
  } else if (savedRightSidebar === 'expanded') {
    sidebarRight?.classList.remove('collapsed');
    document.documentElement.classList.remove('right-sidebar-collapsed');
  }

  if (savedLeftSidebar === 'collapsed') {
    sidebarLeft?.classList.add('collapsed');
  } else if (savedLeftSidebar === 'expanded') {
    sidebarLeft?.classList.remove('collapsed');
  }

  document.getElementById('toggleLeftSidebar')?.addEventListener('click', () => {
    const isCollapsed = sidebarLeft?.classList.toggle('collapsed');
    localStorage.setItem('apex_gym_left_sidebar', isCollapsed ? 'collapsed' : 'expanded');
  });

  document.getElementById('toggleRightSidebar')?.addEventListener('click', () => {
    const isCollapsed = sidebarRight?.classList.toggle('collapsed');
    document.documentElement.classList.toggle('right-sidebar-collapsed', isCollapsed);
    localStorage.setItem('apex_gym_right_sidebar', isCollapsed ? 'collapsed' : 'expanded');
  });

  // Global Search Shortcut (Ctrl+K / Cmd+K)
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      document.getElementById('searchInput')?.focus();
    }
    if (e.key === 'Escape') {
      closeModal();
    }
  });

  // Top Search Input Filter
  document.getElementById('searchInput')?.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase().trim();
    const currentView = getCurrentView();
    if (currentView === 'members') {
      const searchBox = document.getElementById('memberSearch');
      if (searchBox) { searchBox.value = e.target.value; searchBox.dispatchEvent(new Event('input')); }
    } else if (currentView === 'trainers') {
      const searchBox = document.getElementById('trainerSearch');
      if (searchBox) { searchBox.value = e.target.value; searchBox.dispatchEvent(new Event('input')); }
    } else if (currentView === 'attendance') {
      const searchBox = document.getElementById('attendanceSearch');
      if (searchBox) { searchBox.value = e.target.value; searchBox.dispatchEvent(new Event('input')); }
    } else if (currentView === 'payments') {
      const searchBox = document.getElementById('paymentSearch');
      if (searchBox) { searchBox.value = e.target.value; searchBox.dispatchEvent(new Event('input')); }
    }
  });

  // 2. TOAST NOTIFICATIONS
  window.showToast = function (message) {
    const host = document.getElementById('toastContainer') || document.body;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = `${Icons.svg('check')}<span>${message}</span>`;
    host.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
      toast.style.transition = 'all 0.2s ease';
      setTimeout(() => toast.remove(), 200);
    }, 2800);
  };

  // 3. GENERIC MODAL CONTROLLER
  const modalBackdrop = document.getElementById('modalBackdrop');
  const modalContainer = modalBackdrop?.querySelector('.modal');
  const modalForm = document.getElementById('modalForm');

  function openModal({ title, subtitle, fieldsHtml, submitLabel = 'Save', isLarge = false, onSubmit }) {
    if (!modalBackdrop) return;
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalSubtitle').textContent = subtitle || '';
    document.getElementById('modalFormFields').innerHTML = fieldsHtml;
    
    const submitBtn = document.getElementById('modalSubmitBtn');
    if (submitLabel) {
      submitBtn.style.display = 'inline-flex';
      submitBtn.className = 'btn-primary';
      submitBtn.textContent = submitLabel;
    } else {
      submitBtn.style.display = 'none';
    }

    if (modalContainer) {
      modalContainer.classList.toggle('modal-large', isLarge);
    }

    modalBackdrop.classList.add('open');
    Icons.mount(modalBackdrop);

    if (modalForm) {
      modalForm.onsubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData(modalForm);
        const data = Object.fromEntries(formData.entries());
        await onSubmit?.(data, modalForm);
      };
    }
  }

  function closeModal() {
    modalBackdrop?.classList.remove('open');
    if (modalForm) modalForm.onsubmit = null;
  }

  document.getElementById('modalCloseBtn')?.addEventListener('click', closeModal);
  document.getElementById('modalCancelBtn')?.addEventListener('click', closeModal);
  modalBackdrop?.addEventListener('click', (e) => {
    if (e.target.id === 'modalBackdrop') closeModal();
  });

  // 4. ROUTING & MULTI-PAGE NAVIGATION
  const hashToPage = {
    members: 'members.html',
    trainers: 'trainers.html',
    membership: 'membership.html',
    attendance: 'attendance.html',
    payments: 'payments.html',
    settings: 'settings.html'
  };

  const initialHash = window.location.hash.replace('#', '').toLowerCase();
  if (hashToPage[initialHash]) {
    window.location.replace(hashToPage[initialHash]);
    return;
  }

  function getCurrentView() {
    const bodyPage = document.body.dataset.page;
    if (bodyPage) return bodyPage;
    const path = window.location.pathname.split('/').pop().replace('.html', '').toLowerCase();
    const validViews = ['dashboard', 'members', 'trainers', 'membership', 'attendance', 'payments', 'settings'];
    if (validViews.includes(path)) return path;
    const hash = window.location.hash.replace('#', '').toLowerCase();
    if (validViews.includes(hash)) return hash;
    return 'dashboard';
  }

  function switchView(viewName) {
    const views = document.querySelectorAll('.view-container');
    views.forEach(v => {
      v.classList.toggle('active', v.id === `view-${viewName}`);
    });

    document.querySelectorAll('.nav-item[data-nav]').forEach(item => {
      item.classList.toggle('active', item.dataset.nav === viewName);
    });

    const breadcrumbCurrent = document.getElementById('breadcrumbCurrent');
    if (breadcrumbCurrent) {
      const titles = {
        dashboard: 'Dashboard',
        members: 'Members Management',
        trainers: 'Trainers Roster',
        membership: 'Membership Plans',
        attendance: 'Attendance Timesheet',
        payments: 'Payments & Billing',
        settings: 'System Settings'
      };
      breadcrumbCurrent.textContent = titles[viewName] || 'Dashboard';
    }

    if (viewName === 'dashboard') {
      renderDashboard();
    } else if (viewName === 'members') {
      renderMembers();
    } else if (viewName === 'trainers') {
      renderTrainers();
    } else if (viewName === 'membership') {
      renderMembership();
    } else if (viewName === 'attendance') {
      renderAttendance();
    } else if (viewName === 'payments') {
      renderPayments();
    } else if (viewName === 'settings') {
      renderSettings();
    }

    if (window.innerWidth < 900) {
      document.getElementById('sidebarLeft')?.classList.add('collapsed');
    }
  }

  document.querySelectorAll('.nav-item[data-nav]').forEach(link => {
    link.addEventListener('click', (e) => {
      const navTarget = link.dataset.nav;
      const targetPage = navTarget === 'dashboard' ? 'index.html' : `${navTarget}.html`;
      const currentPath = window.location.pathname.split('/').pop().toLowerCase();
      if (currentPath === targetPage.toLowerCase() || (!currentPath && targetPage === 'index.html')) {
        e.preventDefault();
        return;
      }
      e.preventDefault();
      window.location.href = targetPage;
    });
  });

  window.addEventListener('hashchange', () => {
    const newHash = window.location.hash.replace('#', '').toLowerCase();
    if (hashToPage[newHash]) {
      window.location.replace(hashToPage[newHash]);
      return;
    }
    switchView(getCurrentView());
  });

  // 5. VIEW CONTROLLERS

  // A. DASHBOARD VIEW (Rupees ₹)
  function renderDashboard() {
    const stats = GymStore.getStats();
    const settings = GymStore.getSettings();
    const cur = settings.currency || '₹';

    const kpiHost = document.getElementById('kpiGridDashboard');
    if (kpiHost) {
      kpiHost.innerHTML = `
        <article class="kpi-card cyan">
          <div class="kpi-title">
            <span>Total Members</span>
            <span data-icon="users"></span>
          </div>
          <div class="kpi-bottom">
            <div class="kpi-value">${stats.totalMembers.toLocaleString('en-IN')}</div>
            <span class="kpi-trend positive">${Icons.svg('trending-up')} +12.5%</span>
          </div>
        </article>
        <article class="kpi-card periwinkle">
          <div class="kpi-title">
            <span>Active Members</span>
            <span data-icon="user-check"></span>
          </div>
          <div class="kpi-bottom">
            <div class="kpi-value">${stats.activeMembers.toLocaleString('en-IN')}</div>
            <span class="kpi-trend positive">${Icons.svg('trending-up')} 88.9%</span>
          </div>
        </article>
        <article class="kpi-card soft">
          <div class="kpi-title">
            <span>Inactive Members</span>
            <span data-icon="users"></span>
          </div>
          <div class="kpi-bottom">
            <div class="kpi-value">${stats.inactiveMembers.toLocaleString('en-IN')}</div>
            <span class="kpi-trend negative">${Icons.svg('trending-down')} 11.1%</span>
          </div>
        </article>
        <article class="kpi-card cyan">
          <div class="kpi-title">
            <span>Total Trainers</span>
            <span data-icon="briefcase"></span>
          </div>
          <div class="kpi-bottom">
            <div class="kpi-value">${stats.totalTrainers}</div>
            <span class="kpi-trend positive">${Icons.svg('check')} On Duty</span>
          </div>
        </article>
        <article class="kpi-card periwinkle">
          <div class="kpi-title">
            <span>Active Memberships</span>
            <span data-icon="id-card"></span>
          </div>
          <div class="kpi-bottom">
            <div class="kpi-value">${stats.activeMemberships.toLocaleString('en-IN')}</div>
            <span class="kpi-trend positive">${Icons.svg('trending-up')} Paid</span>
          </div>
        </article>
        <article class="kpi-card soft">
          <div class="kpi-title">
            <span>Expired Memberships</span>
            <span data-icon="alert-circle"></span>
          </div>
          <div class="kpi-bottom">
            <div class="kpi-value">${stats.expiredMemberships}</div>
            <span class="kpi-trend negative">${Icons.svg('trending-down')} Needs Renewal</span>
          </div>
        </article>
        <article class="kpi-card cyan">
          <div class="kpi-title">
            <span>Today's Attendance</span>
            <span data-icon="check-circle"></span>
          </div>
          <div class="kpi-bottom">
            <div class="kpi-value">${stats.todayAttendance}</div>
            <span class="kpi-trend positive">${Icons.svg('activity')} Peak Active</span>
          </div>
        </article>
        <article class="kpi-card periwinkle">
          <div class="kpi-title">
            <span>Monthly Revenue</span>
            <span data-icon="wallet"></span>
          </div>
          <div class="kpi-bottom">
            <div class="kpi-value">${cur}${stats.monthlyRevenue.toLocaleString('en-IN')}</div>
            <span class="kpi-trend positive">${Icons.svg('trending-up')} +8.4%</span>
          </div>
        </article>
      `;
    }

    // Recent Members Table
    const recentMembersTable = document.getElementById('recentMembersTableBody');
    if (recentMembersTable) {
      const members = GymStore.get('members').slice(0, 5);
      recentMembersTable.innerHTML = members.map((m, i) => `
        <tr>
          <td>${i + 1}</td>
          <td>
            <div class="user-info-cell">
              <span class="user-avatar ${m.avatarColor || 'avatar-blue'}">${m.name.split(' ').map(x=>x[0]).join('').slice(0,2)}</span>
              <div>
                <div class="user-name-title">${m.name}</div>
                <div class="user-subtext">Trainer: <b>${m.assignedTrainer || 'No Trainer'}</b></div>
              </div>
            </div>
          </td>
          <td>${m.plan}</td>
          <td>${m.joiningDate}</td>
          <td><span class="status-pill ${m.status.toLowerCase()}">${m.status}</span></td>
          <td>
            <button class="table-action-btn" title="View Profile" onclick="window.viewMember('${m.id}')">${Icons.svg('eye')}</button>
          </td>
        </tr>
      `).join('');
    }

    // Recent Payments Table
    const recentPaymentsTable = document.getElementById('recentPaymentsTableBody');
    if (recentPaymentsTable) {
      const payments = GymStore.get('payments').slice(0, 5);
      recentPaymentsTable.innerHTML = payments.map(p => `
        <tr>
          <td><span style="font-weight:600;font-size:12px;">${p.id}</span></td>
          <td>${p.memberName}</td>
          <td>${p.plan}</td>
          <td><b>${cur}${p.amount.toLocaleString('en-IN')}</b></td>
          <td><span class="status-pill ${p.status.toLowerCase()}">${p.status}</span></td>
          <td>
            <button class="table-action-btn" title="View Invoice" onclick="window.previewInvoice('${p.id}')">${Icons.svg('file-text')}</button>
          </td>
        </tr>
      `).join('');
    }

    // Upcoming Expirations Table
    const expiringTable = document.getElementById('upcomingExpirationsTableBody');
    if (expiringTable) {
      const expiring = GymStore.get('members').filter(m => m.status === 'Expired' || m.expiryDate <= '2026-11-20').slice(0, 5);
      expiringTable.innerHTML = expiring.map(m => `
        <tr>
          <td>
            <div class="user-name-title">${m.name}</div>
            <div class="user-subtext">${m.phone} • Trainer: ${m.assignedTrainer || 'None'}</div>
          </td>
          <td>${m.plan}</td>
          <td><span style="color:#E05866;font-weight:500;">${m.expiryDate}</span></td>
          <td>
            <button class="btn-primary" style="padding:4px 10px;font-size:11px;" onclick="window.openRenewModal('${m.id}')">
              ${Icons.svg('zap')} Renew
            </button>
          </td>
        </tr>
      `).join('');
    }

    // Initialize Charts
    if (window.GymCharts) {
      window.GymCharts.initRevenueChart('monthlyRevenueChart');
      window.GymCharts.initMembershipDonutChart('membershipStatsChart', 'membershipDonutLegend');
    }

    Icons.mount();
  }

  // B. MEMBERS MANAGEMENT VIEW (With Assigned Trainer)
  let memberPage = 1;
  const itemsPerPage = 8;
  let memberFilterStatus = '';
  let memberFilterPlan = '';
  let memberSearchQuery = '';

  function renderMembers() {
    const allMembers = GymStore.get('members');
    const plans = GymStore.get('plans');

    const planSelect = document.getElementById('memberPlanFilter');
    if (planSelect && planSelect.options.length <= 1) {
      plans.forEach(p => {
        const opt = document.createElement('option');
        opt.value = p.name;
        opt.textContent = p.name;
        planSelect.appendChild(opt);
      });
    }

    let filtered = allMembers.filter(m => {
      const queryTokens = memberSearchQuery ? memberSearchQuery.split(/\s+/).filter(Boolean) : [];
      const matchesSearch = queryTokens.length === 0 || queryTokens.every(token => {
        return Object.values(m).some(val => {
          if (val == null) return false;
          return String(val).toLowerCase().includes(token);
        });
      });
      const matchesStatus = !memberFilterStatus || m.status.toLowerCase() === memberFilterStatus.toLowerCase();
      const matchesPlan = !memberFilterPlan || m.plan.toLowerCase() === memberFilterPlan.toLowerCase();
      return matchesSearch && matchesStatus && matchesPlan;
    });

    const totalPages = Math.ceil(filtered.length / itemsPerPage) || 1;
    if (memberPage > totalPages) memberPage = totalPages;
    const startIndex = (memberPage - 1) * itemsPerPage;
    const pageItems = filtered.slice(startIndex, startIndex + itemsPerPage);

    const tbody = document.getElementById('membersTableBody');
    if (tbody) {
      if (pageItems.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:36px;color:var(--text-secondary);">No members found matching the criteria.</td></tr>`;
      } else {
        tbody.innerHTML = pageItems.map((m) => `
          <tr>
            <td>
              <div class="user-info-cell">
                <span class="user-avatar ${m.avatarColor || 'avatar-blue'}">
                  ${m.name.split(' ').map(x=>x[0]).join('').slice(0,2)}
                </span>
                <div>
                  <div class="user-name-title">${m.name}</div>
                  <div class="user-subtext">${m.id} • ${m.phone}</div>
                </div>
              </div>
            </td>
            <td><span style="font-weight:500;">${m.plan}</span></td>
            <td>${m.joiningDate}</td>
            <td><span style="${m.status === 'Expired' ? 'color:#E05866;font-weight:600;' : ''}">${m.expiryDate}</span></td>
            <td><span class="status-pill ${m.status.toLowerCase()}">${m.status}</span></td>
            <td>
              <div style="display:flex;gap:4px;">
                <button class="table-action-btn renew" title="Renew Membership" onclick="window.openRenewModal('${m.id}')">${Icons.svg('refresh-cw')}</button>
                <button class="table-action-btn" title="View Profile" onclick="window.viewMember('${m.id}')">${Icons.svg('eye')}</button>
                <button class="table-action-btn" title="Edit Member" onclick="window.editMember('${m.id}')">${Icons.svg('edit')}</button>
                <button class="table-action-btn delete" title="Delete Member" onclick="window.confirmDeleteMember('${m.id}')">${Icons.svg('trash')}</button>
              </div>
            </td>
          </tr>
        `).join('');
      }
    }

    const pageInfo = document.getElementById('membersPageInfo');
    if (pageInfo) {
      pageInfo.textContent = `Showing ${filtered.length ? startIndex + 1 : 0}-${Math.min(startIndex + itemsPerPage, filtered.length)} of ${filtered.length} members`;
    }
    const paginationControls = document.getElementById('membersPaginationControls');
    if (paginationControls) {
      paginationControls.innerHTML = `
        <button class="page-btn" ${memberPage <= 1 ? 'disabled' : ''} onclick="window.changeMemberPage(${memberPage - 1})">${Icons.svg('chevron-left')}</button>
        ${Array.from({ length: totalPages }, (_, i) => i + 1).map(p => `
          <button class="page-btn ${p === memberPage ? 'active' : ''}" onclick="window.changeMemberPage(${p})">${p}</button>
        `).join('')}
        <button class="page-btn" ${memberPage >= totalPages ? 'disabled' : ''} onclick="window.changeMemberPage(${memberPage + 1})">${Icons.svg('chevron-right')}</button>
      `;
    }

    Icons.mount();
  }

  window.changeMemberPage = (p) => {
    memberPage = p;
    renderMembers();
  };

  document.getElementById('memberSearch')?.addEventListener('input', (e) => {
    memberSearchQuery = e.target.value.toLowerCase().trim();
    memberPage = 1;
    renderMembers();
  });
  document.getElementById('memberStatusFilter')?.addEventListener('change', (e) => {
    memberFilterStatus = e.target.value;
    memberPage = 1;
    renderMembers();
  });
  document.getElementById('memberPlanFilter')?.addEventListener('change', (e) => {
    memberFilterPlan = e.target.value;
    memberPage = 1;
    renderMembers();
  });

  // ADD MEMBER MODAL (With Trainer Assignment)
  window.openAddMemberModal = function () {
    const plans = GymStore.get('plans');
    const trainers = GymStore.get('trainers');
    const cur = GymStore.getSettings().currency || '₹';
    const today = new Date().toISOString().split('T')[0];
    const autoId = `GYM-${1000 + GymStore.get('members').length + 1}`;

    const formHtml = `
      <div class="avatar-upload-box">
        <div class="avatar-preview-img" id="memberAvatarPreview">${Icons.svg('users')}</div>
        <div class="avatar-upload-content">
          <label style="font-size:12px;font-weight:600;color:var(--text-primary);cursor:pointer;">
            Upload Photo
            <input type="file" id="memberPhotoInput" accept="image/*" style="display:none;">
          </label>
          <span style="font-size:11px;color:var(--text-secondary);">JPG, PNG up to 2MB</span>
        </div>
      </div>
      <div class="form-row-3">
        <div class="form-group">
          <label>Member ID (Auto-generated)</label>
          <input type="text" name="id" value="${autoId}" readonly style="background:var(--bg-card-subtle);">
        </div>
        <div class="form-group">
          <label>Full Name *</label>
          <input type="text" name="name" required placeholder="e.g. Rahul Sharma">
        </div>
        <div class="form-group">
          <label>Phone Number *</label>
          <input type="tel" name="phone" required placeholder="+91 98765 43210">
        </div>
      </div>
      <div class="form-row-3">
        <div class="form-group">
          <label>Email Address *</label>
          <input type="email" name="email" required placeholder="rahul.sharma@example.com">
        </div>
        <div class="form-group">
          <label>Gender</label>
          <select name="gender">
            <option>Male</option>
            <option>Female</option>
            <option>Other</option>
          </select>
        </div>
        <div class="form-group">
          <label>Date of Birth</label>
          <input type="date" name="dob" value="1995-01-01">
        </div>
      </div>
      <div class="form-row-3">
        <div class="form-group">
          <label>Membership Plan *</label>
          <select name="plan" id="addMemberPlanSelect" required>
            ${plans.map(p => `<option value="${p.name}" data-months="${p.months}">${p.name} (${cur}${p.price.toLocaleString('en-IN')})</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Assign Personal Trainer</label>
          <select name="assignedTrainer">
            <option value="No Trainer" selected>No Trainer (None)</option>
            ${trainers.map(t => `<option value="${t.name}">${t.name} (${t.specialization})</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Status</label>
          <select name="status">
            <option value="Active" selected>Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div class="form-row-3">
        <div class="form-group">
          <label>Start Date</label>
          <input type="date" name="joiningDate" id="addMemberStartDate" value="${today}">
        </div>
        <div class="form-group">
          <label>Expiry Date</label>
          <input type="date" name="expiryDate" id="addMemberExpiryDate" value="${today}">
        </div>
        <div class="form-group">
          <label>Emergency Contact</label>
          <input type="text" name="emergencyContact" placeholder="e.g. Priya Sharma (+91 98765 00011)">
        </div>
      </div>
      <div class="form-group">
        <label>Residential Address</label>
        <input type="text" name="address" placeholder="Street, Flat/House No, City">
      </div>
    `;

    openModal({
      title: 'Add New Member',
      subtitle: 'Register a gym member and assign a fitness coach',
      fieldsHtml: formHtml,
      submitLabel: 'Create Member',
      isLarge: true,
      onSubmit: (data) => {
        if (!data.assignedTrainer) data.assignedTrainer = 'No Trainer';
        GymStore.addMember(data);
        closeModal();
        showToast(`Member ${data.name} added! Assigned Trainer: ${data.assignedTrainer}`);
        renderMembers();
        renderDashboard();
      }
    });

    const planSelect = document.getElementById('addMemberPlanSelect');
    const startInput = document.getElementById('addMemberStartDate');
    const expiryInput = document.getElementById('addMemberExpiryDate');

    function updateExpiry() {
      const selectedPlan = plans.find(p => p.name === planSelect.value);
      const months = selectedPlan ? selectedPlan.months : 1;
      const d = new Date(startInput.value || today);
      d.setMonth(d.getMonth() + months);
      expiryInput.value = d.toISOString().split('T')[0];
    }
    planSelect?.addEventListener('change', updateExpiry);
    startInput?.addEventListener('change', updateExpiry);
    updateExpiry();

    document.getElementById('memberPhotoInput')?.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const preview = document.getElementById('memberAvatarPreview');
          if (preview) {
            preview.style.backgroundImage = `url(${event.target.result})`;
            preview.textContent = '';
          }
        };
        reader.readAsDataURL(file);
      }
    });
  };

  // EDIT MEMBER MODAL
  window.editMember = function (id) {
    const member = GymStore.get('members').find(m => m.id === id);
    if (!member) return;
    const plans = GymStore.get('plans');
    const trainers = GymStore.get('trainers');
    const cur = GymStore.getSettings().currency || '₹';

    const formHtml = `
      <div class="form-row-3">
        <div class="form-group">
          <label>Member ID</label>
          <input type="text" value="${member.id}" readonly style="background:var(--bg-card-subtle);">
        </div>
        <div class="form-group">
          <label>Full Name *</label>
          <input type="text" name="name" required value="${member.name}">
        </div>
        <div class="form-group">
          <label>Phone Number *</label>
          <input type="tel" name="phone" required value="${member.phone}">
        </div>
      </div>
      <div class="form-row-3">
        <div class="form-group">
          <label>Email Address *</label>
          <input type="email" name="email" required value="${member.email}">
        </div>
        <div class="form-group">
          <label>Membership Plan *</label>
          <select name="plan">
            ${plans.map(p => `<option value="${p.name}" ${p.name === member.plan ? 'selected' : ''}>${p.name} (${cur}${p.price})</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Assigned Personal Trainer</label>
          <select name="assignedTrainer">
            <option value="No Trainer" ${(!member.assignedTrainer || member.assignedTrainer === 'No Trainer') ? 'selected' : ''}>No Trainer (None)</option>
            ${trainers.map(t => `
              <option value="${t.name}" ${member.assignedTrainer === t.name ? 'selected' : ''}>
                ${t.name} (${t.specialization})
              </option>
            `).join('')}
          </select>
        </div>
      </div>
      <div class="form-row-3">
        <div class="form-group">
          <label>Status</label>
          <select name="status">
            <option value="Active" ${member.status === 'Active' ? 'selected' : ''}>Active</option>
            <option value="Inactive" ${member.status === 'Inactive' ? 'selected' : ''}>Inactive</option>
            <option value="Expired" ${member.status === 'Expired' ? 'selected' : ''}>Expired</option>
          </select>
        </div>
        <div class="form-group">
          <label>Expiry Date</label>
          <input type="date" name="expiryDate" value="${member.expiryDate}">
        </div>
        <div class="form-group">
          <label>Emergency Contact</label>
          <input type="text" name="emergencyContact" value="${member.emergencyContact || ''}">
        </div>
      </div>
      <div class="form-group">
        <label>Address</label>
        <input type="text" name="address" value="${member.address || ''}">
      </div>
    `;

    openModal({
      title: `Edit Member — ${member.name}`,
      subtitle: `Update details and coach assignment for ${member.id}`,
      fieldsHtml: formHtml,
      submitLabel: 'Save Changes',
      isLarge: true,
      onSubmit: (data) => {
        if (!data.assignedTrainer) data.assignedTrainer = 'No Trainer';
        GymStore.updateMember(id, data);
        closeModal();
        showToast('Member profile updated.');
        renderMembers();
        renderDashboard();
      }
    });
  };

  // VIEW MEMBER PROFILE
  window.viewMember = function (id) {
    const member = GymStore.get('members').find(m => m.id === id);
    if (!member) return;
    const cur = GymStore.getSettings().currency || '₹';

    const attendances = GymStore.get('attendance').filter(a => a.memberId === id);
    const payments = GymStore.get('payments').filter(p => p.memberId === id);

    const profileHtml = `
      <div style="display:flex;align-items:center;gap:16px;padding:16px;background:var(--bg-card-subtle);border-radius:12px;margin-bottom:20px;">
        <span class="user-avatar ${member.avatarColor || 'avatar-blue'}" style="width:54px;height:54px;font-size:18px;">
          ${member.name.split(' ').map(x=>x[0]).join('').slice(0,2)}
        </span>
        <div>
          <h3 style="font-size:18px;font-weight:600;">${member.name}</h3>
          <p style="font-size:12px;color:var(--text-secondary);">${member.id} • ${member.plan} • <span class="status-pill ${member.status.toLowerCase()}">${member.status}</span></p>
        </div>
      </div>

      <div class="form-row" style="margin-bottom:14px;font-size:13px;">
        <div><b>Assigned Trainer:</b> <span style="font-weight:600;color:var(--text-primary);">${member.assignedTrainer || 'No Trainer'}</span></div>
        <div><b>Phone:</b> ${member.phone}</div>
      </div>
      <div class="form-row" style="margin-bottom:14px;font-size:13px;">
        <div><b>Email:</b> ${member.email}</div>
        <div><b>Joined Date:</b> ${member.joiningDate}</div>
      </div>
      <div class="form-row" style="margin-bottom:14px;font-size:13px;">
        <div><b>Membership Expiry:</b> <span style="color:#E05866;font-weight:600;">${member.expiryDate}</span></div>
        <div><b>Emergency Contact:</b> ${member.emergencyContact || 'N/A'}</div>
      </div>
      <div style="font-size:13px;margin-bottom:16px;">
        <b>Address:</b> ${member.address || 'N/A'}
      </div>

      <h4 style="font-size:13px;font-weight:600;margin:16px 0 8px;">Recent Attendance (${attendances.length})</h4>
      <div style="max-height:120px;overflow-y:auto;background:var(--bg-card-subtle);border-radius:8px;padding:8px 12px;font-size:12px;">
        ${attendances.length ? attendances.map(a => `
          <div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--border-light);">
            <span>${a.date} (${a.checkIn} - ${a.checkOut})</span>
            <span class="status-pill ${a.status.toLowerCase()}">${a.status}</span>
          </div>
        `).join('') : '<span style="color:var(--text-secondary);">No check-in history yet.</span>'}
      </div>

      <h4 style="font-size:13px;font-weight:600;margin:16px 0 8px;">Payment Receipts (${payments.length})</h4>
      <div style="max-height:120px;overflow-y:auto;background:var(--bg-card-subtle);border-radius:8px;padding:8px 12px;font-size:12px;">
        ${payments.length ? payments.map(p => `
          <div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--border-light);align-items:center;">
            <span>${p.id} • ${p.plan}</span>
            <span><b>${cur}${p.amount.toLocaleString('en-IN')}</b> (${p.method})</span>
          </div>
        `).join('') : '<span style="color:var(--text-secondary);">No payments recorded.</span>'}
      </div>
    `;

    openModal({
      title: 'Member Profile',
      subtitle: `Complete overview for ${member.name}`,
      fieldsHtml: profileHtml,
      submitLabel: '',
      isLarge: true
    });
  };

  // DELETE MEMBER MODAL
  window.confirmDeleteMember = function (id) {
    const member = GymStore.get('members').find(m => m.id === id);
    if (!member) return;

    openModal({
      title: 'Delete Member',
      subtitle: 'Confirm member deletion',
      fieldsHtml: `
        <div style="padding:10px 0;">
          <p style="font-size:13px;color:var(--text-primary);margin-bottom:12px;">
            Are you sure you want to permanently delete member <b>${member.name}</b> (${member.id})?
          </p>
          <p style="font-size:12px;color:var(--text-secondary);">
            This action cannot be undone. All attendance history and associated records will be removed.
          </p>
        </div>
      `,
      submitLabel: 'Yes, Delete Member',
      onSubmit: () => {
        GymStore.deleteMember(id);
        closeModal();
        showToast(`Member ${member.name} has been deleted.`);
        renderMembers();
        renderDashboard();
      }
    });
    const btn = document.getElementById('modalSubmitBtn');
    if (btn) btn.className = 'btn-danger';
  };

  // C. TRAINERS MANAGEMENT VIEW (LISTED OUT LIKE MEMBERS TABLE - LISTOUT ONLY)
  let trainerSearchQuery = '';
  let trainerFilterSpec = '';
  let trainerFilterStatus = '';

  function renderTrainers() {
    const allTrainers = GymStore.get('trainers');
    const allMembers = GymStore.get('members');

    let filtered = allTrainers.filter(t => {
      const matchSearch = !trainerSearchQuery || 
        t.name.toLowerCase().includes(trainerSearchQuery) ||
        t.id.toLowerCase().includes(trainerSearchQuery) ||
        t.email.toLowerCase().includes(trainerSearchQuery) ||
        t.phone.includes(trainerSearchQuery) ||
        t.specialization.toLowerCase().includes(trainerSearchQuery);
      const matchSpec = !trainerFilterSpec || t.specialization.toLowerCase().includes(trainerFilterSpec.toLowerCase());
      const matchStatus = !trainerFilterStatus || t.status.toLowerCase() === trainerFilterStatus.toLowerCase();
      return matchSearch && matchSpec && matchStatus;
    });

    // Table View (Listed out like Members Table)
    const tbody = document.getElementById('trainersTableBody');
    if (tbody) {
      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;padding:36px;color:var(--text-secondary);">No trainers found matching the search criteria.</td></tr>`;
      } else {
        tbody.innerHTML = filtered.map(t => {
          const traineeMembers = allMembers.filter(m => (m.assignedTrainer || '').trim().toLowerCase() === t.name.trim().toLowerCase());
          return `
            <tr>
              <td class="col-check"><input type="checkbox" data-trainer-check="${t.id}"></td>
              <td>
                <span class="clickable-trainer-link" onclick="window.viewTrainerTrainees('${t.id}')" title="Click to view assigned trainees" style="font-size:12px;font-weight:600;">
                  ${t.id}
                </span>
              </td>
              <td>
                <div class="user-info-cell" style="cursor:pointer;" onclick="window.viewTrainerTrainees('${t.id}')" title="Click to view assigned trainees">
                  <span class="user-avatar ${t.avatarColor || 'avatar-blue'}">
                    ${t.name.split(' ').map(x=>x[0]).join('').slice(0,2)}
                  </span>
                  <div>
                    <div class="user-name-title clickable-trainer-link">${t.name}</div>
                    <div class="user-subtext">${t.email}</div>
                  </div>
                </div>
              </td>
              <td><span style="font-weight:600;color:var(--text-primary);">${t.specialization}</span></td>
              <td>${t.phone}</td>
              <td>${t.joiningDate}</td>
              <td><b>${t.experience}</b></td>
              <td><span style="font-size:12px;color:var(--text-secondary);">${t.availability}</span></td>
              <td>
                <button type="button" class="trainees-count-pill" onclick="window.viewTrainerTrainees('${t.id}')" title="Click to view assigned members">
                  <b>${traineeMembers.length}</b> Trainees
                </button>
              </td>
              <td><span class="status-pill ${t.status.toLowerCase().replace(/\s+/g, '-')}">${t.status}</span></td>
              <td>
                <div style="display:flex;gap:4px;">
                  <button class="table-action-btn" title="View Assigned Trainees" onclick="window.viewTrainerTrainees('${t.id}')">${Icons.svg('eye')}</button>
                  <button class="table-action-btn" title="Edit Trainer" onclick="window.editTrainer('${t.id}')">${Icons.svg('edit')}</button>
                  <button class="table-action-btn delete" title="Delete Trainer" onclick="window.confirmDeleteTrainer('${t.id}')">${Icons.svg('trash')}</button>
                </div>
              </td>
            </tr>
          `;
        }).join('');
      }
    }

    // Update count meta
    const countInfo = document.getElementById('trainersPageInfo');
    if (countInfo) {
      countInfo.textContent = `Showing ${filtered.length} trainers`;
    }

    Icons.mount();
  }

  document.getElementById('trainerSearch')?.addEventListener('input', (e) => {
    trainerSearchQuery = e.target.value.toLowerCase().trim();
    renderTrainers();
  });
  document.getElementById('trainerSpecFilter')?.addEventListener('change', (e) => {
    trainerFilterSpec = e.target.value;
    renderTrainers();
  });
  document.getElementById('trainerStatusFilter')?.addEventListener('change', (e) => {
    trainerFilterStatus = e.target.value;
    renderTrainers();
  });

  // ADD TRAINER MODAL
  window.openAddTrainerModal = function () {
    const cur = GymStore.getSettings().currency || '₹';
    const formHtml = `
      <div class="form-row">
        <div class="form-group">
          <label>Full Name *</label>
          <input type="text" name="name" required placeholder="e.g. Jason Scott">
        </div>
        <div class="form-group">
          <label>Specialization *</label>
          <input type="text" name="specialization" required placeholder="e.g. HIIT & Calisthenics">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Email *</label>
          <input type="email" name="email" required placeholder="jason.s@apexgym.club">
        </div>
        <div class="form-group">
          <label>Phone Number *</label>
          <input type="tel" name="phone" required placeholder="+91 98765 77889">
        </div>
      </div>
      <div class="form-row-3">
        <div class="form-group">
          <label>Experience</label>
          <input type="text" name="experience" placeholder="e.g. 5 Years">
        </div>
        <div class="form-group">
          <label>Salary (${cur})</label>
          <input type="text" name="salary" placeholder="${cur}50,000/mo">
        </div>
        <div class="form-group">
          <label>Status</label>
          <select name="status">
            <option value="Active">Active</option>
            <option value="On Leave">On Leave</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label>Shift / Availability</label>
        <select name="availability">
          <option>Morning (06:00 - 14:00)</option>
          <option>Evening (14:00 - 22:00)</option>
          <option>Full Day (Flexible)</option>
        </select>
      </div>
      <div class="form-group">
        <label>Residential Address</label>
        <input type="text" name="address" placeholder="Trainer Address">
      </div>
    `;

    openModal({
      title: 'Add New Trainer',
      subtitle: 'Onboard a fitness trainer to the gym roster',
      fieldsHtml: formHtml,
      submitLabel: 'Add Trainer',
      isLarge: true,
      onSubmit: (data) => {
        GymStore.addTrainer(data);
        closeModal();
        showToast(`Trainer ${data.name} added!`);
        renderTrainers();
      }
    });
  };

  // EDIT TRAINER MODAL
  window.editTrainer = function (id) {
    const trainer = GymStore.get('trainers').find(t => t.id === id);
    if (!trainer) return;

    const formHtml = `
      <div class="form-row">
        <div class="form-group">
          <label>Trainer ID</label>
          <input type="text" value="${trainer.id}" readonly style="background:var(--bg-card-subtle);">
        </div>
        <div class="form-group">
          <label>Full Name *</label>
          <input type="text" name="name" required value="${trainer.name}">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Specialization</label>
          <input type="text" name="specialization" required value="${trainer.specialization}">
        </div>
        <div class="form-group">
          <label>Experience</label>
          <input type="text" name="experience" value="${trainer.experience}">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Email</label>
          <input type="email" name="email" required value="${trainer.email}">
        </div>
        <div class="form-group">
          <label>Phone</label>
          <input type="tel" name="phone" required value="${trainer.phone}">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Salary</label>
          <input type="text" name="salary" value="${trainer.salary}">
        </div>
        <div class="form-group">
          <label>Status</label>
          <select name="status">
            <option value="Active" ${trainer.status === 'Active' ? 'selected' : ''}>Active</option>
            <option value="On Leave" ${trainer.status === 'On Leave' ? 'selected' : ''}>On Leave</option>
            <option value="Inactive" ${trainer.status === 'Inactive' ? 'selected' : ''}>Inactive</option>
          </select>
        </div>
      </div>
    `;

    openModal({
      title: `Edit Trainer — ${trainer.name}`,
      subtitle: `Update trainer profile and details`,
      fieldsHtml: formHtml,
      submitLabel: 'Save Changes',
      isLarge: true,
      onSubmit: (data) => {
        GymStore.updateTrainer(id, data);
        closeModal();
        showToast('Trainer details updated.');
        renderTrainers();
      }
    });
  };

  // VIEW TRAINER & ASSIGNED TRAINEES POPUP MODAL
  window.viewTrainerTrainees = function (id) {
    const trainer = GymStore.get('trainers').find(t => t.id === id);
    if (!trainer) return;
    const allMembers = GymStore.get('members');
    const trainees = allMembers.filter(m => (m.assignedTrainer || '').trim().toLowerCase() === trainer.name.trim().toLowerCase());

    const contentHtml = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;padding:16px;background:var(--bg-card-subtle);border-radius:12px;margin-bottom:20px;flex-wrap:wrap;border:1px solid var(--border-light);">
        <div style="display:flex;align-items:center;gap:14px;">
          <span class="user-avatar ${trainer.avatarColor || 'avatar-blue'}" style="width:52px;height:52px;font-size:18px;">
            ${trainer.name.split(' ').map(x=>x[0]).join('').slice(0,2)}
          </span>
          <div>
            <div style="display:flex;align-items:center;gap:8px;">
              <h3 style="font-size:17px;font-weight:600;color:var(--text-primary);">${trainer.name}</h3>
              <span class="status-pill ${trainer.status.toLowerCase().replace(/\s+/g, '-')}">${trainer.status}</span>
            </div>
            <p style="font-size:12px;color:var(--text-secondary);margin-top:2px;">
              ${trainer.id} • <b>${trainer.specialization}</b> • Shift: ${trainer.availability}
            </p>
          </div>
        </div>
        <div style="display:flex;gap:16px;font-size:12px;">
          <div>
            <span style="color:var(--text-secondary);display:block;">Phone</span>
            <b>${trainer.phone}</b>
          </div>
          <div>
            <span style="color:var(--text-secondary);display:block;">Experience</span>
            <b>${trainer.experience}</b>
          </div>
          <div>
            <span style="color:var(--text-secondary);display:block;">Assigned Trainees</span>
            <b style="font-size:14px;color:var(--text-primary);">${trainees.length} Members</b>
          </div>
        </div>
      </div>

      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
        <h4 style="font-size:14px;font-weight:600;color:var(--text-primary);">
          Members Currently Training Under ${trainer.name} (${trainees.length})
        </h4>
        <button type="button" class="btn-secondary" style="padding:4px 10px;font-size:12px;" onclick="window.assignNewMemberToTrainer('${trainer.name.replace(/'/g, "\\'")}')">
          ${Icons.svg('plus')} Assign Member
        </button>
      </div>

      ${trainees.length > 0 ? `
        <div class="table-wrapper" style="max-height:360px;overflow-y:auto;border:1px solid var(--border-color);border-radius:8px;">
          <table class="snow-ui-table">
            <thead>
              <tr>
                <th>Member ID</th>
                <th>Member Name</th>
                <th>Plan</th>
                <th>Phone Number</th>
                <th>Expiry Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              ${trainees.map(m => `
                <tr>
                  <td><span style="font-weight:600;font-size:12px;">${m.id}</span></td>
                  <td>
                    <div class="user-info-cell">
                      <span class="user-avatar ${m.avatarColor || 'avatar-blue'}" style="width:28px;height:28px;font-size:11px;">
                        ${m.name.split(' ').map(x=>x[0]).join('').slice(0,2)}
                      </span>
                      <div>
                        <div class="user-name-title" style="font-size:13px;">${m.name}</div>
                        <div class="user-subtext" style="font-size:11px;">${m.email}</div>
                      </div>
                    </div>
                  </td>
                  <td><span style="font-weight:500;">${m.plan}</span></td>
                  <td>${m.phone}</td>
                  <td><span style="${m.status === 'Expired' ? 'color:#E05866;font-weight:600;' : ''}">${m.expiryDate}</span></td>
                  <td><span class="status-pill ${m.status.toLowerCase()}">${m.status}</span></td>
                  <td>
                    <button class="table-action-btn" title="View Full Member Profile" onclick="window.viewMember('${m.id}')">${Icons.svg('eye')}</button>
                  </td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : `
        <div style="text-align:center;padding:36px 16px;background:var(--bg-card-subtle);border:1px dashed var(--border-color);border-radius:8px;">
          <p style="font-size:13.5px;font-weight:600;color:var(--text-primary);margin-bottom:6px;">No members currently training under ${trainer.name}</p>
          <p style="font-size:12px;color:var(--text-secondary);margin-bottom:14px;">Select this trainer when registering or editing a member to have them appear here.</p>
          <button type="button" class="btn-primary" style="margin:0 auto;" onclick="window.assignNewMemberToTrainer('${trainer.name.replace(/'/g, "\\'")}')">
            ${Icons.svg('plus')} Assign a Member to ${trainer.name}
          </button>
        </div>
      `}
    `;

    openModal({
      title: `Trainees Under ${trainer.name}`,
      subtitle: `Viewing all gym members training with ${trainer.name}`,
      fieldsHtml: contentHtml,
      submitLabel: '',
      isLarge: true
    });
  };

  window.viewTrainer = window.viewTrainerTrainees;

  window.assignNewMemberToTrainer = function (trainerName) {
    closeModal();
    window.openAddMemberModal();
    setTimeout(() => {
      const select = document.querySelector('select[name="assignedTrainer"]');
      if (select) {
        select.value = trainerName;
      }
    }, 100);
  };

  // DELETE TRAINER
  window.confirmDeleteTrainer = function (id) {
    const trainer = GymStore.get('trainers').find(t => t.id === id);
    if (!trainer) return;

    openModal({
      title: 'Delete Trainer',
      subtitle: 'Remove trainer from system',
      fieldsHtml: `
        <div style="padding:10px 0;">
          <p style="font-size:13px;color:var(--text-primary);margin-bottom:8px;">
            Are you sure you want to remove trainer <b>${trainer.name}</b> (${trainer.id})?
          </p>
        </div>
      `,
      submitLabel: 'Yes, Delete',
      onSubmit: () => {
        GymStore.deleteTrainer(id);
        closeModal();
        showToast(`Trainer ${trainer.name} removed.`);
        renderTrainers();
      }
    });
    const btn = document.getElementById('modalSubmitBtn');
    if (btn) btn.className = 'btn-danger';
  };

  // D. MEMBERSHIP PLANS & PRICING EDIT VIEW (WITH EDIT PLAN OPTION!)
  function renderMembership() {
    const plans = GymStore.get('plans');
    const members = GymStore.get('members');
    const settings = GymStore.getSettings();
    const cur = settings.currency || '₹';

    // 1. Render Pricing Cards (With EDIT PLAN Button)
    const pricingHost = document.getElementById('pricingCardsContainer');
    if (pricingHost) {
      pricingHost.innerHTML = plans.map(p => `
        <div class="pricing-card ${p.featured ? 'featured' : ''}">
          ${p.featured ? '<span class="pricing-badge">Popular</span>' : ''}
          <div class="pricing-header">
            <h3 class="pricing-plan-name">${p.name}</h3>
            <span class="pricing-duration">${p.duration} Commitment</span>
          </div>

          <div class="pricing-price-box">
            <span class="pricing-currency">${cur}</span>
            <span class="pricing-amount">${p.price.toLocaleString('en-IN')}</span>
            <span class="pricing-cycle">/${p.duration.toLowerCase()}</span>
          </div>

          <ul class="pricing-features">
            ${p.features.map(f => `
              <li>${Icons.svg('check')} <span>${f}</span></li>
            `).join('')}
          </ul>

          <div class="pricing-actions">
            <button class="btn-primary" style="flex:1;justify-content:center;" onclick="window.openEditPlanModal('${p.id}')">
              ${Icons.svg('edit')} Edit Plan &amp; Price
            </button>
          </div>
        </div>
      `).join('');
    }

    // 2. Render Active / Expired Membership List
    const membershipListBody = document.getElementById('membershipListTableBody');
    if (membershipListBody) {
      membershipListBody.innerHTML = members.map(m => `
        <tr>
          <td>
            <div class="user-info-cell">
              <span class="user-avatar ${m.avatarColor || 'avatar-blue'}">${m.name.split(' ').map(x=>x[0]).join('').slice(0,2)}</span>
              <div>
                <div class="user-name-title">${m.name}</div>
                <div class="user-subtext">${m.id} • Coach: ${m.assignedTrainer || 'None'}</div>
              </div>
            </div>
          </td>
          <td><b>${m.plan}</b></td>
          <td>${m.joiningDate}</td>
          <td><span style="${m.status === 'Expired' ? 'color:#E05866;font-weight:600;' : ''}">${m.expiryDate}</span></td>
          <td><span class="status-pill ${m.status.toLowerCase()}">${m.status}</span></td>
          <td>
            <button class="btn-primary" style="padding:4px 10px;font-size:11px;" onclick="window.openRenewModal('${m.id}')">
              ${Icons.svg('zap')} Renew Plan
            </button>
          </td>
        </tr>
      `).join('');
    }

    Icons.mount();
  }

  // EDIT MEMBERSHIP PLAN & PRICE MODAL
  window.openEditPlanModal = function (planId) {
    const plans = GymStore.get('plans');
    const plan = plans.find(p => p.id === planId) || plans[0];
    const cur = GymStore.getSettings().currency || '₹';

    const featuresText = (plan.features || []).join('\n');

    const formHtml = `
      <div class="form-row">
        <div class="form-group">
          <label>Plan ID</label>
          <input type="text" value="${plan.id}" readonly style="background:var(--bg-card-subtle);">
        </div>
        <div class="form-group">
          <label>Plan Name *</label>
          <input type="text" name="name" required value="${plan.name}">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Plan Price (${cur}) *</label>
          <input type="number" name="price" required value="${plan.price}" min="0">
        </div>
        <div class="form-group">
          <label>Duration Display (e.g. 1 Month, 3 Months, 1 Year)</label>
          <input type="text" name="duration" required value="${plan.duration}">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Duration in Months (for auto-expiry calculation)</label>
          <input type="number" name="months" required value="${plan.months || 1}" min="1">
        </div>
        <div class="form-group">
          <label>Plan Status</label>
          <select name="status">
            <option value="Active" ${plan.status === 'Active' ? 'selected' : ''}>Active</option>
            <option value="Inactive" ${plan.status === 'Inactive' ? 'selected' : ''}>Inactive</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label>Plan Features (One feature per line)</label>
        <textarea name="featuresText" rows="5" style="resize:vertical;">${featuresText}</textarea>
      </div>
      <div class="form-group">
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:500;">
          <input type="checkbox" name="featured" value="true" ${plan.featured ? 'checked' : ''} style="width:16px;height:16px;accent-color:var(--color-black);">
          Display as Popular / Best Value Plan (Highlighted Card)
        </label>
      </div>
    `;

    openModal({
      title: `Edit Membership Plan — ${plan.name}`,
      subtitle: `Update pricing in ${cur}, duration & features list`,
      fieldsHtml: formHtml,
      submitLabel: 'Save Plan Changes',
      isLarge: true,
      onSubmit: (data) => {
        const parsedFeatures = (data.featuresText || '')
          .split('\n')
          .map(f => f.trim())
          .filter(f => f.length > 0);

        const updated = {
          name: data.name,
          price: parseFloat(data.price) || 0,
          duration: data.duration,
          months: parseInt(data.months, 10) || 1,
          status: data.status,
          featured: !!data.featured,
          features: parsedFeatures
        };

        GymStore.updatePlan(planId, updated);
        closeModal();
        showToast(`Membership plan "${updated.name}" updated! Price: ${cur}${updated.price.toLocaleString('en-IN')}`);
        renderMembership();
        renderDashboard();
      }
    });
  };

  // RENEW MEMBERSHIP MODAL
  window.openRenewModal = function (memberId) {
    const member = GymStore.get('members').find(m => m.id === memberId);
    if (!member) return;
    const plans = GymStore.get('plans');
    const cur = GymStore.getSettings().currency || '₹';

    const formHtml = `
      <div style="padding:8px 0 16px;">
        <p style="font-size:13px;color:var(--text-primary);">
          Renewing membership for <b>${member.name}</b> (${member.id}).
        </p>
        <p style="font-size:12px;color:var(--text-secondary);margin-top:2px;">
          Current Plan: ${member.plan} | Expiry: ${member.expiryDate}
        </p>
      </div>
      <div class="form-group">
        <label>Select Plan for Renewal</label>
        <select name="planId" id="renewPlanSelect">
          ${plans.map(p => `
            <option value="${p.id}" ${p.name === member.plan ? 'selected' : ''}>
              ${p.name} (${cur}${p.price.toLocaleString('en-IN')} / ${p.duration})
            </option>
          `).join('')}
        </select>
      </div>
      <div class="form-group">
        <label>Payment Method</label>
        <select name="paymentMethod">
          <option>UPI</option>
          <option>Card</option>
          <option>Cash</option>
          <option>Bank Transfer</option>
        </select>
      </div>
    `;

    openModal({
      title: 'Renew Membership',
      subtitle: 'Extend membership duration and log receipt',
      fieldsHtml: formHtml,
      submitLabel: 'Process Renewal',
      onSubmit: (data) => {
        const res = GymStore.renewMembership(memberId, data.planId, data.paymentMethod);
        closeModal();
        if (res.ok) {
          showToast(`Membership renewed until ${res.member.expiryDate}!`);
          renderMembership();
          renderMembers();
          renderDashboard();
        }
      }
    });
  };

  // E. ATTENDANCE MANAGEMENT VIEW
  let attendanceSearchQuery = '';
  let attendanceFilterStatus = '';

  function renderAttendance() {
    const allAttendance = GymStore.get('attendance');
    const members = GymStore.get('members');

    const memberSelect = document.getElementById('checkInMemberSelect');
    if (memberSelect && memberSelect.options.length <= 1) {
      members.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m.id;
        opt.textContent = `${m.name} (${m.id})`;
        memberSelect.appendChild(opt);
      });
    }

    const today = '2026-11-14';
    const todayPresent = allAttendance.filter(a => a.date === today);
    const inGymCount = allAttendance.filter(a => a.date === today && a.status === 'In-Gym').length;

    const presentEl = document.getElementById('attTodayPresent');
    const inGymEl = document.getElementById('attInGym');
    const rateEl = document.getElementById('attRate');
    if (presentEl) presentEl.textContent = todayPresent.length + 336;
    if (inGymEl) inGymEl.textContent = inGymCount + 48;
    if (rateEl) rateEl.textContent = '84.2%';

    let filtered = allAttendance.filter(a => {
      const member = members.find(m => m.id === a.memberId) || {};
      const queryTokens = attendanceSearchQuery ? attendanceSearchQuery.split(/\s+/).filter(Boolean) : [];
      const matchesSearch = queryTokens.length === 0 || queryTokens.every(token => {
        const matchAttendance = Object.values(a).some(val => val != null && String(val).toLowerCase().includes(token));
        const matchMember = Object.values(member).some(val => val != null && String(val).toLowerCase().includes(token));
        return matchAttendance || matchMember;
      });
      const matchesStatus = !attendanceFilterStatus || a.status.toLowerCase() === attendanceFilterStatus.toLowerCase();
      return matchesSearch && matchesStatus;
    });

    const pageInfo = document.getElementById('attendancePageInfo');
    if (pageInfo) {
      pageInfo.textContent = `Showing ${filtered.length} of ${allAttendance.length} check-ins`;
    }

    const tbody = document.getElementById('attendanceTableBody');
    if (tbody) {
      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:36px;color:var(--text-secondary);">No check-in records found matching the criteria.</td></tr>`;
      } else {
        tbody.innerHTML = filtered.map(a => `
          <tr>
            <td><span style="font-weight:600;font-size:12px;">${a.memberId}</span></td>
            <td><b>${a.memberName}</b></td>
            <td><span style="color:#249A6E;font-weight:500;">${a.checkIn}</span></td>
            <td><span style="color:${a.checkOut === '--:--' ? 'var(--text-secondary)' : '#E05866'};font-weight:500;">${a.checkOut}</span></td>
            <td>${a.date}</td>
            <td><span class="status-pill ${a.status.toLowerCase()}">${a.status}</span></td>
            <td>
              ${a.status === 'In-Gym' ? `
                <button class="btn-primary" style="padding:3px 8px;font-size:11px;" onclick="window.checkOutAttendance('${a.id}')">
                  Check Out
                </button>
              ` : '<span style="font-size:11px;color:var(--text-secondary);">Logged</span>'}
            </td>
          </tr>
        `).join('');
      }
    }

    renderCalendar();
    Icons.mount();
  }

  function renderCalendar() {
    const grid = document.getElementById('attendanceCalendarGrid');
    if (!grid) return;
    const daysInNov = 30;
    const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    let html = dayNames.map(d => `<div class="calendar-day-head">${d}</div>`).join('');
    for (let i = 1; i <= daysInNov; i++) {
      const isToday = i === 14;
      const count = isToday ? 342 : Math.floor(280 + (i * 3.7) % 80);
      html += `
        <div class="calendar-day ${isToday ? 'today' : ''}">
          <span class="calendar-day-num">${i} Nov</span>
          <div class="calendar-day-stat">
            <span class="calendar-dot"></span>
            <span>${count} in</span>
          </div>
        </div>
      `;
    }
    grid.innerHTML = html;
  }

  window.submitQuickCheckIn = function () {
    const select = document.getElementById('checkInMemberSelect');
    if (!select || !select.value) {
      alert('Please select a member to check in.');
      return;
    }
    const res = GymStore.checkInMember(select.value);
    if (!res.ok) {
      alert(res.error);
    } else {
      showToast(`${res.data.memberName} checked in!`);
      renderAttendance();
      renderDashboard();
    }
  };

  window.checkOutAttendance = function (attendanceId) {
    const res = GymStore.checkOutMember(attendanceId);
    if (res.ok) {
      showToast(`${res.data.memberName} checked out.`);
      renderAttendance();
      renderDashboard();
    }
  };

  document.getElementById('attendanceSearch')?.addEventListener('input', (e) => {
    attendanceSearchQuery = e.target.value.toLowerCase().trim();
    renderAttendance();
  });

  document.getElementById('attendanceStatusFilter')?.addEventListener('change', (e) => {
    attendanceFilterStatus = e.target.value;
    renderAttendance();
  });

  // F. PAYMENTS & BILLING VIEW (In Rupees ₹)
  let paymentSearchQuery = '';
  let paymentFilterMethod = '';
  let paymentFilterStatus = '';

  function renderPayments() {
    const allPayments = GymStore.get('payments');
    const settings = GymStore.getSettings();
    const cur = settings.currency || '₹';

    let filtered = allPayments.filter(p => {
      const matchSearch = !paymentSearchQuery || 
        p.id.toLowerCase().includes(paymentSearchQuery) ||
        p.memberName.toLowerCase().includes(paymentSearchQuery) ||
        p.plan.toLowerCase().includes(paymentSearchQuery);
      const matchMethod = !paymentFilterMethod || p.method.toLowerCase() === paymentFilterMethod.toLowerCase();
      const matchStatus = !paymentFilterStatus || p.status.toLowerCase() === paymentFilterStatus.toLowerCase();
      return matchSearch && matchMethod && matchStatus;
    });

    const tbody = document.getElementById('paymentsTableBody');
    if (tbody) {
      if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:36px;color:var(--text-secondary);">No payment transactions found.</td></tr>`;
      } else {
        tbody.innerHTML = filtered.map(p => `
          <tr>
            <td><span style="font-weight:600;font-size:12px;">${p.id}</span></td>
            <td><b>${p.memberName}</b></td>
            <td>${p.plan}</td>
            <td><b>${cur}${p.amount.toLocaleString('en-IN')}</b></td>
            <td>${p.date}</td>
            <td><span class="status-pill ${p.method.toLowerCase().replace(/\s+/g, '-')}">${p.method}</span></td>
            <td><span class="status-pill ${p.status.toLowerCase()}">${p.status}</span></td>
            <td>
              <div style="display:flex;gap:4px;">
                <button class="table-action-btn" title="View & Print Invoice" onclick="window.previewInvoice('${p.id}')">${Icons.svg('file-text')}</button>
                <button class="table-action-btn" title="Download Receipt" onclick="window.downloadInvoiceStub('${p.id}')">${Icons.svg('download')}</button>
              </div>
            </td>
          </tr>
        `).join('');
      }
    }

    if (window.GymCharts) {
      window.GymCharts.initPaymentMethodsChart('paymentMethodsChart', 'paymentMethodsLegend');
    }
    Icons.mount();
  }

  document.getElementById('paymentSearch')?.addEventListener('input', (e) => {
    paymentSearchQuery = e.target.value.toLowerCase().trim();
    renderPayments();
  });
  document.getElementById('paymentMethodFilter')?.addEventListener('change', (e) => {
    paymentFilterMethod = e.target.value;
    renderPayments();
  });
  document.getElementById('paymentStatusFilter')?.addEventListener('change', (e) => {
    paymentFilterStatus = e.target.value;
    renderPayments();
  });

  // RECORD PAYMENT MODAL (In Rupees ₹)
  window.openRecordPaymentModal = function () {
    const members = GymStore.get('members');
    const plans = GymStore.get('plans');
    const cur = GymStore.getSettings().currency || '₹';

    const formHtml = `
      <div class="form-group">
        <label>Select Member *</label>
        <select name="memberId" id="payMemberSelect" required>
          ${members.map(m => `<option value="${m.id}" data-name="${m.name}" data-plan="${m.plan}">${m.name} (${m.id})</option>`).join('')}
        </select>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Membership Plan</label>
          <select name="plan" id="payPlanSelect">
            ${plans.map(p => `<option value="${p.name}" data-price="${p.price}">${p.name} (${cur}${p.price})</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Amount (${cur}) *</label>
          <input type="number" name="amount" id="payAmountInput" value="${plans[0]?.price || 1499}" required>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Payment Method</label>
          <select name="method">
            <option>UPI</option>
            <option>Card</option>
            <option>Cash</option>
            <option>Bank Transfer</option>
          </select>
        </div>
        <div class="form-group">
          <label>Status</label>
          <select name="status">
            <option value="Paid">Paid</option>
            <option value="Pending">Pending</option>
          </select>
        </div>
      </div>
    `;

    openModal({
      title: 'Record Payment',
      subtitle: `Log fee collection in ${cur} and generate invoice receipt`,
      fieldsHtml: formHtml,
      submitLabel: 'Save Transaction',
      onSubmit: (data) => {
        const memSelect = document.getElementById('payMemberSelect');
        const selectedOpt = memSelect.options[memSelect.selectedIndex];
        data.memberName = selectedOpt.dataset.name;
        data.amount = parseFloat(data.amount) || 0;

        GymStore.addPayment(data);
        closeModal();
        showToast(`Payment of ${cur}${data.amount.toLocaleString('en-IN')} recorded!`);
        renderPayments();
        renderDashboard();
      }
    });

    const planSelect = document.getElementById('payPlanSelect');
    const amountInput = document.getElementById('payAmountInput');
    planSelect?.addEventListener('change', () => {
      const selected = plans.find(p => p.name === planSelect.value);
      if (selected && amountInput) amountInput.value = selected.price;
    });
  };

  // INVOICE PREVIEW MODAL (Rupees ₹)
  window.previewInvoice = function (txnId) {
    const payment = GymStore.get('payments').find(p => p.id === txnId) || GymStore.get('payments')[0];
    const settings = GymStore.getSettings();
    const cur = settings.currency || '₹';
    const subtotal = payment.amount;
    const tax = Math.round(subtotal * 0.05 * 100) / 100;
    const total = subtotal + tax;

    const invoiceHtml = `
      <div class="invoice-container">
        <div class="invoice-top">
          <div class="invoice-logo-area">
            <span class="brand-icon" style="width:36px;height:36px;">${Icons.svg('dumbbell')}</span>
            <div>
              <div class="invoice-gym-name">${settings.gymName}</div>
              <p style="font-size:11px;color:var(--text-secondary);">${settings.tagline}</p>
            </div>
          </div>
          <div class="invoice-badge-paid">${payment.status}</div>
        </div>

        <div class="invoice-meta-grid">
          <div class="invoice-meta-block">
            <h4>Billed To</h4>
            <b>${payment.memberName}</b><br>
            <span>Member ID: ${payment.memberId || 'GYM-1001'}</span><br>
            <span>Status: Active Club Member</span>
          </div>
          <div class="invoice-meta-block" style="text-align:right;">
            <h4>Invoice Details</h4>
            <b>Invoice: ${payment.invoiceNo || 'INV-2026-0891'}</b><br>
            <span>Txn ID: ${payment.id}</span><br>
            <span>Date: ${payment.date}</span><br>
            <span>Payment Method: ${payment.method}</span>
          </div>
        </div>

        <table class="invoice-table">
          <thead>
            <tr>
              <th style="text-align:left;">Description</th>
              <th style="text-align:center;">Duration</th>
              <th style="text-align:right;">Rate</th>
              <th style="text-align:right;">Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <b>${payment.plan}</b>
                <div style="font-size:11px;color:var(--text-secondary);">Full gym equipment access, locker, assessments</div>
              </td>
              <td style="text-align:center;">Valid Cycle</td>
              <td style="text-align:right;">${cur}${subtotal.toLocaleString('en-IN')}</td>
              <td style="text-align:right;"><b>${cur}${subtotal.toLocaleString('en-IN')}</b></td>
            </tr>
          </tbody>
        </table>

        <div class="invoice-total-row">
          <span style="color:var(--text-secondary);">GST (5%):</span>
          <span>${cur}${tax.toLocaleString('en-IN')}</span>
        </div>
        <div class="invoice-total-row">
          <span><b>Total Paid:</b></span>
          <span><b>${cur}${total.toLocaleString('en-IN')}</b></span>
        </div>

        <div style="margin-top:28px;padding-top:14px;border-top:1px solid var(--border-light);font-size:11px;color:var(--text-secondary);display:flex;justify-content:space-between;">
          <span>${settings.address} • ${settings.phone}</span>
          <span>GSTIN: ${settings.taxId}</span>
        </div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:20px;">
        <button class="btn-secondary" onclick="window.print()">${Icons.svg('printer')} Print Invoice</button>
        <button class="btn-primary" onclick="window.downloadInvoiceStub('${payment.id}')">${Icons.svg('download')} Download PDF</button>
      </div>
    `;

    openModal({
      title: `Invoice — ${payment.invoiceNo || payment.id}`,
      subtitle: `Official gym tax invoice and receipt in ${cur}`,
      fieldsHtml: invoiceHtml,
      submitLabel: '',
      isLarge: true
    });
  };

  window.downloadInvoiceStub = function (id) {
    showToast(`Invoice ${id} download initiated.`);
  };

  // G. SETTINGS VIEW
  function renderSettings() {
    const s = GymStore.getSettings();

    const setVal = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.value = val !== undefined ? val : '';
    };

    setVal('setGymName', s.gymName);
    setVal('setTagline', s.tagline);
    setVal('setPhone', s.phone);
    setVal('setEmail', s.email);
    setVal('setAddress', s.address);
    setVal('setTaxId', s.taxId);
    setVal('setCurrency', s.currency || '₹');
    setVal('setDateFormat', s.dateFormat);
    setVal('setAdminName', s.adminName);
    setVal('setAdminRole', s.adminRole);
    setVal('setAdminEmail', s.adminEmail);
    setVal('setAdminPhone', s.adminPhone);

    const emailCb = document.getElementById('setNotifEmail');
    if (emailCb) emailCb.checked = !!s.notifEmail;
    const smsCb = document.getElementById('setNotifSms');
    if (smsCb) smsCb.checked = !!s.notifSms;

    const themeSelect = document.getElementById('setThemeMode');
    if (themeSelect) {
      themeSelect.value = document.documentElement.classList.contains('dark') ? 'dark' : 'light';
    }

    document.querySelectorAll('.settings-nav-btn').forEach(btn => {
      btn.onclick = () => {
        document.querySelectorAll('.settings-nav-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.settings-tab-pane').forEach(p => p.classList.remove('active'));
        btn.classList.add('active');
        const target = document.getElementById(`settings-pane-${btn.dataset.tab}`);
        if (target) target.classList.add('active');
      };
    });

    Icons.mount();
  }

  // Save Settings Form
  window.saveGymSettings = function (e) {
    e?.preventDefault();
    const s = {
      gymName: document.getElementById('setGymName')?.value,
      tagline: document.getElementById('setTagline')?.value,
      phone: document.getElementById('setPhone')?.value,
      email: document.getElementById('setEmail')?.value,
      address: document.getElementById('setAddress')?.value,
      taxId: document.getElementById('setTaxId')?.value,
      currency: document.getElementById('setCurrency')?.value || '₹',
      dateFormat: document.getElementById('setDateFormat')?.value,
      adminName: document.getElementById('setAdminName')?.value,
      adminRole: document.getElementById('setAdminRole')?.value,
      adminEmail: document.getElementById('setAdminEmail')?.value,
      adminPhone: document.getElementById('setAdminPhone')?.value,
      notifEmail: document.getElementById('setNotifEmail')?.checked,
      notifSms: document.getElementById('setNotifSms')?.checked
    };

    GymStore.saveSettings(s);

    const themeMode = document.getElementById('setThemeMode')?.value;
    if (themeMode) {
      const isDarkNow = themeMode === 'dark';
      document.documentElement.classList.toggle('dark', isDarkNow);
      document.body.classList.toggle('dark', isDarkNow);
      localStorage.setItem(THEME_KEY, isDarkNow ? 'dark' : 'light');
      if (window.GymCharts) window.GymCharts.refreshAll();
    }

    const brandNameEl = document.getElementById('headerBrandName');
    if (brandNameEl) brandNameEl.textContent = s.gymName;

    const userChipName = document.getElementById('userChipAdminName');
    if (userChipName) userChipName.textContent = s.adminName;

    showToast('Settings saved successfully!');
  };

  // RIGHT SIDEBAR LIVE FEED
  function renderRightRail() {
    const list = document.getElementById('activitiesList');
    if (!list) return;
    const activities = GymStore.get('activities');
    list.innerHTML = activities.slice(0, 5).map(a => `
      <div class="notice-item">
        <div class="user-avatar" style="width:28px;height:28px;background:${a.bg};color:${a.color};font-size:10px;">
          ${a.initials}
        </div>
        <div class="notice-details">
          <span class="notice-text">${a.text}</span>
          <span class="notice-time">${a.time}</span>
        </div>
      </div>
    `).join('');
  }

  // 6. INITIAL APPLICATION MOUNT
  const initialView = getCurrentView();
  switchView(initialView);
  renderRightRail();
  Icons.mount();
});
