/**
 * Chart initialization and rendering for Gym Management System
 * Integrates with Chart.js and adapts to Light/Dark modes seamlessly with Rupee currency.
 */
window.GymCharts = (() => {
  const chartInstances = {};

  function getThemeColors() {
    const isDark = document.documentElement.classList.contains('dark') || document.body.classList.contains('dark');
    return {
      isDark,
      textColor: isDark ? '#FFFFFF' : '#1C1C1C',
      mutedText: isDark ? 'rgba(255, 255, 255, 0.45)' : 'rgba(28, 28, 28, 0.4)',
      gridColor: isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(28, 28, 28, 0.08)',
      cardBg: isDark ? '#242424' : '#FFFFFF',
      cyan: '#85CBFF',
      sky: '#95A4FC',
      mint: '#A1E3CB',
      purple: '#C6C7F8',
      black: isDark ? '#FFFFFF' : '#1C1C1C'
    };
  }

  function initRevenueChart(canvasId = 'monthlyRevenueChart') {
    const el = document.getElementById(canvasId);
    if (!el || !window.Chart) return;

    if (chartInstances[canvasId]) {
      chartInstances[canvasId].destroy();
    }

    const t = getThemeColors();
    const cur = (window.GymStore && window.GymStore.getSettings().currency) || '₹';
    const labels = ['Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov (Current)'];
    const revenueData = [320000, 350000, 375000, 390000, 410000, 428500];
    const targetData = [300000, 330000, 360000, 380000, 400000, 420000];

    chartInstances[canvasId] = new Chart(el, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label: `Actual Revenue (${cur})`,
            data: revenueData,
            borderColor: t.black,
            backgroundColor: 'transparent',
            borderWidth: 2.5,
            tension: 0.4,
            cubicInterpolationMode: 'monotone',
            pointRadius: 3,
            pointHoverRadius: 6,
            pointBackgroundColor: t.black
          },
          {
            label: `Monthly Target (${cur})`,
            data: targetData,
            borderColor: '#95A4FC',
            borderDash: [5, 5],
            backgroundColor: 'transparent',
            borderWidth: 2,
            tension: 0.4,
            pointRadius: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#1C1C1C',
            titleColor: '#FFFFFF',
            bodyColor: '#FFFFFF',
            padding: 10,
            cornerRadius: 8,
            titleFont: { family: 'Inter', size: 12, weight: '600' },
            bodyFont: { family: 'Inter', size: 12 },
            callbacks: {
              label: (ctx) => ` ${ctx.dataset.label}: ${cur}${ctx.raw.toLocaleString('en-IN')}`
            }
          }
        },
        scales: {
          x: {
            grid: { display: false, drawBorder: false },
            ticks: { color: t.mutedText, font: { family: 'Inter', size: 11 } },
            border: { display: false }
          },
          y: {
            grid: { color: t.gridColor, drawBorder: false },
            ticks: {
              color: t.mutedText,
              font: { family: 'Inter', size: 11 },
              callback: (val) => `${cur}${(val / 1000).toFixed(0)}k`
            },
            border: { display: false }
          }
        }
      }
    });
  }

  function initMembershipDonutChart(canvasId = 'membershipStatsChart', legendId = 'membershipDonutLegend') {
    const el = document.getElementById(canvasId);
    if (!el || !window.Chart) return;

    if (chartInstances[canvasId]) {
      chartInstances[canvasId].destroy();
    }

    const t = getThemeColors();
    const plans = [
      { name: 'Yearly VIP Pro', count: 485, color: '#1C1C1C' },
      { name: 'Half-Yearly Elite', count: 340, color: '#95A4FC' },
      { name: 'Quarterly Fit', count: 265, color: '#85CBFF' },
      { name: 'Monthly Flex', count: 144, color: '#A1E3CB' },
      { name: 'Custom VIP', count: 50, color: '#C6C7F8' }
    ];

    const total = plans.reduce((acc, p) => acc + p.count, 0);

    chartInstances[canvasId] = new Chart(el, {
      type: 'doughnut',
      data: {
        labels: plans.map(p => p.name),
        datasets: [{
          data: plans.map(p => p.count),
          backgroundColor: plans.map(p => (t.isDark && p.color === '#1C1C1C') ? '#FFFFFF' : p.color),
          borderWidth: 0,
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '72%',
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#1C1C1C',
            titleColor: '#FFFFFF',
            bodyColor: '#FFFFFF',
            padding: 10,
            cornerRadius: 8,
            titleFont: { family: 'Inter', size: 12 },
            bodyFont: { family: 'Inter', size: 12 },
            callbacks: {
              label: (ctx) => ` ${ctx.label}: ${ctx.raw} (${Math.round((ctx.raw / total) * 100)}%)`
            }
          }
        }
      }
    });

    const legEl = document.getElementById(legendId);
    if (legEl) {
      legEl.innerHTML = plans.map(p => {
        const pct = Math.round((p.count / total) * 100);
        const col = (t.isDark && p.color === '#1C1C1C') ? '#FFFFFF' : p.color;
        return `
          <div class="legend-item" style="display:flex;align-items:center;justify-content:space-between;width:100%;gap:12px;">
            <div style="display:flex;align-items:center;gap:6px;">
              <span class="legend-bullet" style="background:${col}"></span>
              <span style="color:var(--text-primary);font-size:12px;">${p.name}</span>
            </div>
            <span style="font-weight:600;font-size:12px;color:var(--text-secondary);">${pct}%</span>
          </div>
        `;
      }).join('');
    }
  }

  function initPaymentMethodsChart(canvasId = 'paymentMethodsChart', legendId = 'paymentMethodsLegend') {
    const el = document.getElementById(canvasId);
    if (!el || !window.Chart) return;

    if (chartInstances[canvasId]) {
      chartInstances[canvasId].destroy();
    }

    const t = getThemeColors();
    const methods = [
      { name: 'UPI', pct: 52, color: '#A1E3CB' },
      { name: 'Card', pct: 28, color: '#85CBFF' },
      { name: 'Cash', pct: 12, color: '#C6C7F8' },
      { name: 'Bank Transfer', pct: 8, color: '#95A4FC' }
    ];

    chartInstances[canvasId] = new Chart(el, {
      type: 'doughnut',
      data: {
        labels: methods.map(m => m.name),
        datasets: [{
          data: methods.map(m => m.pct),
          backgroundColor: methods.map(m => m.color),
          borderWidth: 0,
          hoverOffset: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '70%',
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#1C1C1C',
            titleColor: '#FFFFFF',
            bodyColor: '#FFFFFF',
            padding: 10,
            cornerRadius: 8,
            callbacks: {
              label: (ctx) => ` ${ctx.label}: ${ctx.raw}%`
            }
          }
        }
      }
    });

    const legEl = document.getElementById(legendId);
    if (legEl) {
      legEl.innerHTML = methods.map(m => `
        <div class="legend-item" style="display:flex;align-items:center;justify-content:space-between;width:100%;gap:12px;">
          <div style="display:flex;align-items:center;gap:6px;">
            <span class="legend-bullet" style="background:${m.color}"></span>
            <span style="color:var(--text-primary);font-size:12px;">${m.name}</span>
          </div>
          <span style="font-weight:600;font-size:12px;color:var(--text-secondary);">${m.pct}%</span>
        </div>
      `).join('');
    }
  }

  function refreshAll() {
    initRevenueChart();
    initMembershipDonutChart();
    initPaymentMethodsChart();
  }

  return {
    initRevenueChart,
    initMembershipDonutChart,
    initPaymentMethodsChart,
    refreshAll
  };
})();
