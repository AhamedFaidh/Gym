/**
 * Gym Management System - Reactive LocalStorage Data Store
 * Provides rich initial sample data in Rupees (₹) and local CRUD operations.
 */
window.GymStore = (() => {
  const STORAGE_KEY = 'apex_gym_store_v2'; // v2 with Rupees & Trainer assignment

  const INITIAL_SEED = {
    settings: {
      gymName: 'Apex Gym & Fitness',
      tagline: 'Elite Strength & Conditioning Club',
      phone: '+91 98765 43210',
      email: 'contact@apexgym.club',
      address: '742 Evergreen Heights, MG Road, Metro City',
      taxId: 'GSTIN-29AAAAA0000A1Z5',
      currency: '₹',
      dateFormat: 'YYYY-MM-DD',
      notifEmail: true,
      notifSms: true,
      adminName: 'Marcus Vance',
      adminRole: 'Head Administrator & Operations Director',
      adminEmail: 'marcus.vance@apexgym.club',
      adminPhone: '+91 98765 11223'
    },
    plans: [
      {
        id: 'plan-monthly',
        name: 'Monthly Flex',
        duration: '1 Month',
        months: 1,
        price: 1499,
        featured: false,
        status: 'Active',
        features: [
          'Full Gym Floor Access',
          'Standard Locker Facility',
          'Free Fitness Assessment',
          'Mobile Check-in Access'
        ]
      },
      {
        id: 'plan-quarterly',
        name: 'Quarterly Fit',
        duration: '3 Months',
        months: 3,
        price: 3999,
        featured: false,
        status: 'Active',
        features: [
          'All Monthly Flex features',
          '2 Personal Training Sessions',
          'Personalized Diet Plan',
          'Free InBody Body Scan'
        ]
      },
      {
        id: 'plan-half-yearly',
        name: 'Half-Yearly Elite',
        duration: '6 Months',
        months: 6,
        price: 6999,
        featured: false,
        status: 'Active',
        features: [
          'All Quarterly Fit features',
          '5 Personal Training Sessions',
          'Nutritionist Consultation',
          'Sauna & Steam Bath Access',
          '2 Guest Passes / Month'
        ]
      },
      {
        id: 'plan-yearly',
        name: 'Yearly VIP Pro',
        duration: '12 Months',
        months: 12,
        price: 11999,
        featured: true,
        status: 'Active',
        features: [
          'BEST VALUE - Complete Access',
          '12 Personal Training Sessions',
          'Unlimited Steam & Sauna',
          'Complimentary Gym Merch Kit',
          'Reserved Executive Locker',
          'Free Towel Service'
        ]
      },
      {
        id: 'plan-custom',
        name: 'Custom VIP / Athlete',
        duration: '12 Months',
        months: 12,
        price: 19999,
        featured: false,
        status: 'Active',
        features: [
          'Dedicated Strength Coach',
          'Bi-weekly Physio Review',
          'Custom Recovery Protocols',
          '24/7 Priority Concierge Access'
        ]
      }
    ],
    members: [
      {
        id: 'GYM-1001',
        name: 'David Reynolds',
        email: 'david.reynolds@example.com',
        phone: '+91 98234 56789',
        gender: 'Male',
        dob: '1992-05-14',
        address: '42 Pine Hill Road, Metro City',
        emergencyContact: 'Sarah Reynolds (+91 98234 99011)',
        plan: 'Yearly VIP Pro',
        planId: 'plan-yearly',
        assignedTrainer: 'Brandon Walsh',
        joiningDate: '2025-11-15',
        expiryDate: '2026-11-15',
        status: 'Active',
        avatarColor: 'avatar-green',
        avatarUrl: ''
      },
      {
        id: 'GYM-1002',
        name: 'Elena Rostova',
        email: 'elena.rostova@example.com',
        phone: '+91 98876 54321',
        gender: 'Female',
        dob: '1996-08-22',
        address: '18 Oakwood Blvd, Metro City',
        emergencyContact: 'Igor Rostova (+91 98876 00000)',
        plan: 'Half-Yearly Elite',
        planId: 'plan-half-yearly',
        assignedTrainer: 'Seraphina Lin',
        joiningDate: '2026-06-01',
        expiryDate: '2026-12-01',
        status: 'Active',
        avatarColor: 'avatar-purple',
        avatarUrl: ''
      },
      {
        id: 'GYM-1003',
        name: 'Alexander Hayes',
        email: 'alex.hayes@example.com',
        phone: '+91 98345 67890',
        gender: 'Male',
        dob: '1989-11-30',
        address: '77 Sunset Strip, Apt 4B',
        emergencyContact: 'Clara Hayes (+91 98345 11223)',
        plan: 'Quarterly Fit',
        planId: 'plan-quarterly',
        assignedTrainer: 'Marcus Karr',
        joiningDate: '2026-08-20',
        expiryDate: '2026-11-20',
        status: 'Active',
        avatarColor: 'avatar-blue',
        avatarUrl: ''
      },
      {
        id: 'GYM-1004',
        name: 'Chloe Bennett',
        email: 'chloe.bennett@example.com',
        phone: '+91 98456 78901',
        gender: 'Female',
        dob: '1998-03-12',
        address: '109 Riverside Dr',
        emergencyContact: 'Mark Bennett (+91 98456 33445)',
        plan: 'Monthly Flex',
        planId: 'plan-monthly',
        assignedTrainer: 'No Trainer',
        joiningDate: '2026-10-10',
        expiryDate: '2026-11-10',
        status: 'Expired',
        avatarColor: 'avatar-peach',
        avatarUrl: ''
      },
      {
        id: 'GYM-1005',
        name: 'Michael Chen',
        email: 'michael.chen@example.com',
        phone: '+91 98567 89012',
        gender: 'Male',
        dob: '1994-09-18',
        address: '350 Willow Creek, Metro City',
        emergencyContact: 'Grace Chen (+91 98567 99881)',
        plan: 'Yearly VIP Pro',
        planId: 'plan-yearly',
        assignedTrainer: 'Darius Thorne',
        joiningDate: '2026-01-10',
        expiryDate: '2027-01-10',
        status: 'Active',
        avatarColor: 'avatar-cyan',
        avatarUrl: ''
      },
      {
        id: 'GYM-1006',
        name: 'Sophia Patel',
        email: 'sophia.patel@example.com',
        phone: '+91 98678 90123',
        gender: 'Female',
        dob: '1995-12-04',
        address: '22 Elm Court, Metro City',
        emergencyContact: 'Raj Patel (+91 98678 77112)',
        plan: 'Half-Yearly Elite',
        planId: 'plan-half-yearly',
        assignedTrainer: 'Natasha Roman',
        joiningDate: '2026-05-18',
        expiryDate: '2026-11-18',
        status: 'Active',
        avatarColor: 'avatar-purple',
        avatarUrl: ''
      },
      {
        id: 'GYM-1007',
        name: 'James O’Connor',
        email: 'james.oconnor@example.com',
        phone: '+91 98789 01234',
        gender: 'Male',
        dob: '1987-07-25',
        address: '88 Highland Ave',
        emergencyContact: 'Fiona O’Connor (+91 98789 44556)',
        plan: 'Custom VIP / Athlete',
        planId: 'plan-custom',
        assignedTrainer: 'Brandon Walsh',
        joiningDate: '2026-03-01',
        expiryDate: '2027-03-01',
        status: 'Active',
        avatarColor: 'avatar-blue',
        avatarUrl: ''
      },
      {
        id: 'GYM-1008',
        name: 'Victoria Adams',
        email: 'victoria.adams@example.com',
        phone: '+91 98890 12345',
        gender: 'Female',
        dob: '2000-01-15',
        address: '15 Maple Lane',
        emergencyContact: 'Robert Adams (+91 98890 99223)',
        plan: 'Monthly Flex',
        planId: 'plan-monthly',
        assignedTrainer: 'No Trainer',
        joiningDate: '2026-10-28',
        expiryDate: '2026-11-28',
        status: 'Active',
        avatarColor: 'avatar-peach',
        avatarUrl: ''
      },
      {
        id: 'GYM-1009',
        name: 'Lucas Morales',
        email: 'lucas.morales@example.com',
        phone: '+91 98901 23456',
        gender: 'Male',
        dob: '1991-04-09',
        address: '501 Marina Blvd',
        emergencyContact: 'Lucia Morales (+91 98901 11002)',
        plan: 'Quarterly Fit',
        planId: 'plan-quarterly',
        assignedTrainer: 'Marcus Karr',
        joiningDate: '2026-09-05',
        expiryDate: '2026-12-05',
        status: 'Active',
        avatarColor: 'avatar-green',
        avatarUrl: ''
      },
      {
        id: 'GYM-1010',
        name: 'Emma Watson',
        email: 'emma.watson@example.com',
        phone: '+91 98012 34567',
        gender: 'Female',
        dob: '1997-06-30',
        address: '73 Beacon St',
        emergencyContact: 'Thomas Watson (+91 98012 88776)',
        plan: 'Monthly Flex',
        planId: 'plan-monthly',
        assignedTrainer: 'No Trainer',
        joiningDate: '2026-09-12',
        expiryDate: '2026-10-12',
        status: 'Expired',
        avatarColor: 'avatar-purple',
        avatarUrl: ''
      },
      {
        id: 'GYM-1011',
        name: 'Ryan Gallagher',
        email: 'ryan.g@example.com',
        phone: '+91 98123 98765',
        gender: 'Male',
        dob: '1993-10-10',
        address: '144 Cedar Wood Rd',
        emergencyContact: 'Nancy Gallagher (+91 98123 55667)',
        plan: 'Yearly VIP Pro',
        planId: 'plan-yearly',
        assignedTrainer: 'Brandon Walsh',
        joiningDate: '2026-02-14',
        expiryDate: '2027-02-14',
        status: 'Active',
        avatarColor: 'avatar-cyan',
        avatarUrl: ''
      },
      {
        id: 'GYM-1012',
        name: 'Zoe Kravitz',
        email: 'zoe.kravitz@example.com',
        phone: '+91 98234 87654',
        gender: 'Female',
        dob: '1999-02-17',
        address: '92 Parkview Terrace',
        emergencyContact: 'Leonard Kravitz (+91 98234 33221)',
        plan: 'Quarterly Fit',
        planId: 'plan-quarterly',
        assignedTrainer: 'Seraphina Lin',
        joiningDate: '2026-10-01',
        expiryDate: '2027-01-01',
        status: 'Active',
        avatarColor: 'avatar-peach',
        avatarUrl: ''
      }
    ],
    trainers: [
      {
        id: 'TR-101',
        name: 'Brandon Walsh',
        specialization: 'Strength & Bodybuilding',
        experience: '8 Years',
        phone: '+91 98701 22441',
        email: 'brandon.w@apexgym.club',
        gender: 'Male',
        dob: '1988-03-15',
        address: '12 Pioneer Way, Metro City',
        salary: '₹55,000/mo',
        availability: 'Morning (06:00 - 14:00)',
        joiningDate: '2023-01-15',
        assignedMembers: 48,
        status: 'Active',
        avatarColor: 'avatar-blue'
      },
      {
        id: 'TR-102',
        name: 'Seraphina Lin',
        specialization: 'Yoga & Functional Mobility',
        experience: '6 Years',
        phone: '+91 98702 33552',
        email: 'seraphina.lin@apexgym.club',
        gender: 'Female',
        dob: '1992-07-20',
        address: '88 Serenity Path, Metro City',
        salary: '₹48,000/mo',
        availability: 'Evening (14:00 - 22:00)',
        joiningDate: '2023-05-10',
        assignedMembers: 36,
        status: 'Active',
        avatarColor: 'avatar-green'
      },
      {
        id: 'TR-103',
        name: 'Marcus Karr',
        specialization: 'CrossFit & Olympic Lifting',
        experience: '9 Years',
        phone: '+91 98703 44663',
        email: 'marcus.k@apexgym.club',
        gender: 'Male',
        dob: '1986-11-08',
        address: '204 Iron Works Blvd',
        salary: '₹58,000/mo',
        availability: 'Morning (06:00 - 14:00)',
        joiningDate: '2022-09-01',
        assignedMembers: 52,
        status: 'Active',
        avatarColor: 'avatar-cyan'
      },
      {
        id: 'TR-104',
        name: 'Natasha Roman',
        specialization: 'Cardio HIIT & Calisthenics',
        experience: '5 Years',
        phone: '+91 98704 55774',
        email: 'natasha.r@apexgym.club',
        gender: 'Female',
        dob: '1994-04-12',
        address: '39 Zenith Ct, Metro City',
        salary: '₹45,000/mo',
        availability: 'Evening (14:00 - 22:00)',
        joiningDate: '2024-02-20',
        assignedMembers: 41,
        status: 'Active',
        avatarColor: 'avatar-peach'
      },
      {
        id: 'TR-105',
        name: 'Darius Thorne',
        specialization: 'Sports Conditioning & Rehab',
        experience: '11 Years',
        phone: '+91 98705 66885',
        email: 'darius.t@apexgym.club',
        gender: 'Male',
        dob: '1984-09-29',
        address: '61 Olympic Village, Metro City',
        salary: '₹65,000/mo',
        availability: 'Full Day (Flexible)',
        joiningDate: '2021-08-15',
        assignedMembers: 58,
        status: 'Active',
        avatarColor: 'avatar-purple'
      },
      {
        id: 'TR-106',
        name: 'Maya Al-Mansoor',
        specialization: 'Pilates & Core Dynamics',
        experience: '7 Years',
        phone: '+91 98706 77996',
        email: 'maya.m@apexgym.club',
        gender: 'Female',
        dob: '1991-12-03',
        address: '17 Lotus Crescent',
        salary: '₹50,000/mo',
        availability: 'Morning (06:00 - 14:00)',
        joiningDate: '2023-11-01',
        assignedMembers: 34,
        status: 'On Leave',
        avatarColor: 'avatar-green'
      }
    ],
    attendance: [
      {
        id: 'ATT-901',
        memberId: 'GYM-1001',
        memberName: 'David Reynolds',
        date: '2026-11-14',
        checkIn: '06:45 AM',
        checkOut: '08:15 AM',
        status: 'Completed'
      },
      {
        id: 'ATT-902',
        memberId: 'GYM-1002',
        memberName: 'Elena Rostova',
        date: '2026-11-14',
        checkIn: '07:10 AM',
        checkOut: '08:40 AM',
        status: 'Completed'
      },
      {
        id: 'ATT-903',
        memberId: 'GYM-1005',
        memberName: 'Michael Chen',
        date: '2026-11-14',
        checkIn: '08:00 AM',
        checkOut: '--:--',
        status: 'In-Gym'
      },
      {
        id: 'ATT-904',
        memberId: 'GYM-1007',
        memberName: 'James O’Connor',
        date: '2026-11-14',
        checkIn: '08:30 AM',
        checkOut: '--:--',
        status: 'In-Gym'
      },
      {
        id: 'ATT-905',
        memberId: 'GYM-1008',
        memberName: 'Victoria Adams',
        date: '2026-11-14',
        checkIn: '09:15 AM',
        checkOut: '--:--',
        status: 'In-Gym'
      },
      {
        id: 'ATT-906',
        memberId: 'GYM-1009',
        memberName: 'Lucas Morales',
        date: '2026-11-14',
        checkIn: '09:40 AM',
        checkOut: '--:--',
        status: 'In-Gym'
      },
      {
        id: 'ATT-907',
        memberId: 'GYM-1003',
        memberName: 'Alexander Hayes',
        date: '2026-11-13',
        checkIn: '06:30 AM',
        checkOut: '07:45 AM',
        status: 'Completed'
      },
      {
        id: 'ATT-908',
        memberId: 'GYM-1006',
        memberName: 'Sophia Patel',
        date: '2026-11-13',
        checkIn: '05:30 PM',
        checkOut: '06:50 PM',
        status: 'Completed'
      },
      {
        id: 'ATT-909',
        memberId: 'GYM-1011',
        memberName: 'Ryan Gallagher',
        date: '2026-11-13',
        checkIn: '07:00 PM',
        checkOut: '08:30 PM',
        status: 'Completed'
      },
      {
        id: 'ATT-910',
        memberId: 'GYM-1012',
        memberName: 'Zoe Kravitz',
        date: '2026-11-13',
        checkIn: '08:15 AM',
        checkOut: '09:30 AM',
        status: 'Completed'
      }
    ],
    payments: [
      {
        id: 'TXN-88491',
        memberId: 'GYM-1001',
        memberName: 'David Reynolds',
        plan: 'Yearly VIP Pro',
        amount: 11999,
        date: '2026-11-12',
        method: 'UPI',
        status: 'Paid',
        invoiceNo: 'INV-2026-0891'
      },
      {
        id: 'TXN-88490',
        memberId: 'GYM-1008',
        memberName: 'Victoria Adams',
        plan: 'Monthly Flex',
        amount: 1499,
        date: '2026-11-11',
        method: 'Card',
        status: 'Paid',
        invoiceNo: 'INV-2026-0890'
      },
      {
        id: 'TXN-88489',
        memberId: 'GYM-1012',
        memberName: 'Zoe Kravitz',
        plan: 'Quarterly Fit',
        amount: 3999,
        date: '2026-11-09',
        method: 'Cash',
        status: 'Paid',
        invoiceNo: 'INV-2026-0889'
      },
      {
        id: 'TXN-88488',
        memberId: 'GYM-1007',
        memberName: 'James O’Connor',
        plan: 'Custom VIP / Athlete',
        amount: 19999,
        date: '2026-11-05',
        method: 'Bank Transfer',
        status: 'Paid',
        invoiceNo: 'INV-2026-0888'
      },
      {
        id: 'TXN-88487',
        memberId: 'GYM-1004',
        memberName: 'Chloe Bennett',
        plan: 'Monthly Flex Renewal',
        amount: 1499,
        date: '2026-11-03',
        method: 'Card',
        status: 'Pending',
        invoiceNo: 'INV-2026-0887'
      },
      {
        id: 'TXN-88486',
        memberId: 'GYM-1009',
        memberName: 'Lucas Morales',
        plan: 'Quarterly Fit',
        amount: 3999,
        date: '2026-10-28',
        method: 'UPI',
        status: 'Paid',
        invoiceNo: 'INV-2026-0886'
      },
      {
        id: 'TXN-88485',
        memberId: 'GYM-1006',
        memberName: 'Sophia Patel',
        plan: 'Half-Yearly Elite',
        amount: 6999,
        date: '2026-10-20',
        method: 'Card',
        status: 'Paid',
        invoiceNo: 'INV-2026-0885'
      },
      {
        id: 'TXN-88484',
        memberId: 'GYM-1010',
        memberName: 'Emma Watson',
        plan: 'Monthly Flex',
        amount: 1499,
        date: '2026-10-12',
        method: 'UPI',
        status: 'Pending',
        invoiceNo: 'INV-2026-0884'
      }
    ],
    activities: [
      {
        initials: 'DR',
        color: '#15803D',
        bg: '#DCFCE7',
        text: 'David Reynolds checked in for morning session.',
        time: '18 minutes ago'
      },
      {
        initials: 'BW',
        color: '#3B6FD9',
        bg: '#E3F5FF',
        text: 'Trainer Brandon Walsh assigned 2 new VIP trainees.',
        time: '45 minutes ago'
      },
      {
        initials: 'VA',
        color: '#C2410C',
        bg: '#FFEDD5',
        text: 'Victoria Adams paid ₹1,499 for Monthly Flex.',
        time: '2 hours ago'
      },
      {
        initials: 'ER',
        color: '#7E22CE',
        bg: '#F3E8FF',
        text: 'Elena Rostova booked Physio consultation.',
        time: '3 hours ago'
      }
    ]
  };

  function clone(val) {
    return JSON.parse(JSON.stringify(val));
  }

  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        return Object.assign({}, INITIAL_SEED, parsed);
      }
    } catch (e) {
      console.warn('Failed to parse localStorage, resetting to initial seed.', e);
    }
    return clone(INITIAL_SEED);
  }

  let db = load();

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
    } catch (e) {
      console.error('Storage quota exceeded', e);
    }
  }

  function getStats() {
    const totalMembers = db.members.length + 1270;
    const activeMembers = db.members.filter(m => m.status === 'Active').length + 1130;
    const inactiveMembers = db.members.filter(m => m.status === 'Inactive' || m.status === 'Expired').length + 140;
    const totalTrainers = db.trainers.length + 12;
    const activeMemberships = activeMembers;
    const expiredMemberships = db.members.filter(m => m.status === 'Expired').length + 22;
    const todayAttendance = db.attendance.filter(a => a.date === '2026-11-14').length + 336;
    const monthlyRevenue = db.payments
      .filter(p => p.status === 'Paid')
      .reduce((sum, p) => sum + p.amount, 0) + 385000;

    return {
      totalMembers,
      activeMembers,
      inactiveMembers,
      totalTrainers,
      activeMemberships,
      expiredMemberships,
      todayAttendance,
      monthlyRevenue
    };
  }

  return {
    get: (key) => db[key] || [],
    getSettings: () => db.settings,
    saveSettings: (newSettings) => {
      db.settings = Object.assign({}, db.settings, newSettings);
      save();
      return db.settings;
    },
    getStats,
    updatePlan: (id, planData) => {
      const idx = db.plans.findIndex(p => p.id === id);
      if (idx !== -1) {
        db.plans[idx] = Object.assign({}, db.plans[idx], planData);
        save();
        return db.plans[idx];
      }
      return null;
    },
    addMember: (memberData) => {
      const idNum = 1000 + db.members.length + 1;
      const newMember = Object.assign({
        id: `GYM-${idNum}`,
        avatarColor: ['avatar-blue', 'avatar-green', 'avatar-purple', 'avatar-peach', 'avatar-cyan'][db.members.length % 5],
        status: 'Active',
        assignedTrainer: memberData.assignedTrainer || 'No Trainer',
        joiningDate: new Date().toISOString().split('T')[0]
      }, memberData);
      db.members.unshift(newMember);
      
      // Auto record initial payment
      const plan = db.plans.find(p => p.id === newMember.planId || p.name === newMember.plan);
      if (plan) {
        db.payments.unshift({
          id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
          memberId: newMember.id,
          memberName: newMember.name,
          plan: plan.name,
          amount: plan.price,
          date: new Date().toISOString().split('T')[0],
          method: 'Card',
          status: 'Paid',
          invoiceNo: `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`
        });
      }

      db.activities.unshift({
        initials: (newMember.name || 'NM').split(' ').map(x => x[0]).join('').slice(0, 2),
        color: '#15803D',
        bg: '#DCFCE7',
        text: `New member: ${newMember.name} (${newMember.plan}, Trainer: ${newMember.assignedTrainer})`,
        time: 'Just now'
      });

      save();
      return newMember;
    },
    updateMember: (id, memberData) => {
      const idx = db.members.findIndex(m => m.id === id);
      if (idx !== -1) {
        db.members[idx] = Object.assign({}, db.members[idx], memberData);
        save();
        return db.members[idx];
      }
      return null;
    },
    deleteMember: (id) => {
      const idx = db.members.findIndex(m => m.id === id);
      if (idx !== -1) {
        const deleted = db.members.splice(idx, 1)[0];
        save();
        return deleted;
      }
      return null;
    },
    addTrainer: (trainerData) => {
      const idNum = 100 + db.trainers.length + 1;
      const newTrainer = Object.assign({
        id: `TR-${idNum}`,
        avatarColor: 'avatar-blue',
        assignedMembers: 0,
        status: 'Active',
        joiningDate: new Date().toISOString().split('T')[0]
      }, trainerData);
      db.trainers.unshift(newTrainer);
      save();
      return newTrainer;
    },
    updateTrainer: (id, trainerData) => {
      const idx = db.trainers.findIndex(t => t.id === id);
      if (idx !== -1) {
        db.trainers[idx] = Object.assign({}, db.trainers[idx], trainerData);
        save();
        return db.trainers[idx];
      }
      return null;
    },
    deleteTrainer: (id) => {
      const idx = db.trainers.findIndex(t => t.id === id);
      if (idx !== -1) {
        const deleted = db.trainers.splice(idx, 1)[0];
        save();
        return deleted;
      }
      return null;
    },
    checkInMember: (memberId) => {
      const member = db.members.find(m => m.id === memberId);
      if (!member) return { ok: false, error: 'Member not found' };

      const today = new Date().toISOString().split('T')[0];
      const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      // Check if already checked in today and not checked out
      const existing = db.attendance.find(a => a.memberId === memberId && a.date === today && a.status === 'In-Gym');
      if (existing) {
        return { ok: false, error: `${member.name} is already checked in.` };
      }

      const rec = {
        id: `ATT-${Math.floor(1000 + Math.random() * 9000)}`,
        memberId: member.id,
        memberName: member.name,
        date: today,
        checkIn: timeStr,
        checkOut: '--:--',
        status: 'In-Gym'
      };
      db.attendance.unshift(rec);

      db.activities.unshift({
        initials: member.name.split(' ').map(x => x[0]).join('').slice(0, 2),
        color: '#15803D',
        bg: '#DCFCE7',
        text: `${member.name} checked into the gym.`,
        time: 'Just now'
      });

      save();
      return { ok: true, data: rec };
    },
    checkOutMember: (attendanceId) => {
      const rec = db.attendance.find(a => a.id === attendanceId);
      if (!rec) return { ok: false, error: 'Attendance record not found' };

      rec.checkOut = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      rec.status = 'Completed';

      db.activities.unshift({
        initials: rec.memberName.split(' ').map(x => x[0]).join('').slice(0, 2),
        color: '#3B6FD9',
        bg: '#E3F5FF',
        text: `${rec.memberName} completed workout session.`,
        time: 'Just now'
      });

      save();
      return { ok: true, data: rec };
    },
    addPayment: (paymentData) => {
      const newPay = Object.assign({
        id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
        date: new Date().toISOString().split('T')[0],
        status: 'Paid',
        invoiceNo: `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`
      }, paymentData);
      db.payments.unshift(newPay);

      db.activities.unshift({
        initials: (newPay.memberName || 'PM').split(' ').map(x => x[0]).join('').slice(0, 2),
        color: '#C2410C',
        bg: '#FFEDD5',
        text: `Payment of ₹${newPay.amount.toLocaleString('en-IN')} recorded for ${newPay.memberName}`,
        time: 'Just now'
      });

      save();
      return newPay;
    },
    renewMembership: (memberId, planId, method) => {
      const member = db.members.find(m => m.id === memberId);
      const plan = db.plans.find(p => p.id === planId) || db.plans[0];
      if (!member) return { ok: false, error: 'Member not found' };

      const now = new Date();
      now.setMonth(now.getMonth() + (plan.months || 1));
      const newExpiry = now.toISOString().split('T')[0];

      member.plan = plan.name;
      member.planId = plan.id;
      member.expiryDate = newExpiry;
      member.status = 'Active';

      const txn = {
        id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
        memberId: member.id,
        memberName: member.name,
        plan: `${plan.name} (Renewal)`,
        amount: plan.price,
        date: new Date().toISOString().split('T')[0],
        method: method || 'UPI',
        status: 'Paid',
        invoiceNo: `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`
      };
      db.payments.unshift(txn);

      db.activities.unshift({
        initials: member.name.split(' ').map(x => x[0]).join('').slice(0, 2),
        color: '#15803D',
        bg: '#DCFCE7',
        text: `Membership renewed for ${member.name} (${plan.name})`,
        time: 'Just now'
      });

      save();
      return { ok: true, member, txn };
    },
    resetToDefaults: () => {
      db = clone(INITIAL_SEED);
      save();
      return db;
    }
  };
})();
